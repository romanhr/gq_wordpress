<?php

/* ------------------------------------------------------------------*/
/* CREATE THE HELP TAB */
/* ------------------------------------------------------------------*/

function wprs_help_center() {
	
	ob_start(); 
	?>
	
<div class="tab_content" id="help">

	<p> 
	<a href="#shortcodes"><?php _e('Shortcodes', 'wprs'); ?></a>
	</p>

	<!--
	<hr />
	<a href="#wpr-options"><?php _e('top', 'wprs'); ?></a>
	-->
    
	<h3 id="shortcodes"><?php _e('Shortcodes', 'wprs'); ?></h3>
	
	<p><?php _e('There are some shortcodes that you can use directly in the content of your pages, or posts, to display reviews details. For example:', 'wprs'); ?></p>
    <h4 id="rating-box"><?php _e('Pros', 'wprs'); ?></h4>
<pre><code>[wprs-pros]</code></pre>
	<p><?php _e('This will display Pros.','wprs'); ?></p>
	
    <h4 id="rating-box"><?php _e('Cons', 'wprs'); ?></h4>
<pre><code>[wprs-cons]</code></pre>
	<p><?php _e('This will display Cons.','wprs'); ?></p>
	
    

</div>

	<?php
	echo ob_get_clean();
}

?>