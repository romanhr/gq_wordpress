<?php

/* ------------------------------------------------------------------*/
/* SHORTCODES */
/* ------------------------------------------------------------------*/

// Display Simple Content [option id="field_id"]
function wprs_shortcode_option( $atts, $content = null)	{

	global $wprs_options;
	
	extract( shortcode_atts( 
	array(
	      'id' => ''
	      ), $atts ) );

	$content =$wprs_options["$id"];
	
	return $content;
}
add_shortcode('option', 'wprs_shortcode_option');

// Display Image [image id="field_id"]
function wprs_shortcode_image( $atts, $content = null)	{

	global $wprs_options;

	extract( shortcode_atts( 
	array(
	      'id' => ''
	      ), $atts ) );
	      
	// Get attachment data
	$image_data = wp_get_attachment_image_src( $wprs_options["$id"], '' );
	
	// get URL
	$url = $image_data[0];

	$content = '<img src="'.$url.'" />';
	
	return $content;
}
add_shortcode('image', 'wprs_shortcode_image');

?>