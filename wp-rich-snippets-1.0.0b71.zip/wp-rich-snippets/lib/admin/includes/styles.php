<?php

/* ----------------------------------------
* load CSS
----------------------------------------- */

function wprs_admin_styles() {
	if( is_admin() ) {
		wp_enqueue_style('thickbox');
		wp_enqueue_style('eto-admin', WPRS_PLUGIN_DIR.'includes/css/admin-styles.css');
		wp_enqueue_style('jquery-ui-custom', WPRS_PLUGIN_DIR.'includes/css/jquery-ui-custom.css');
	}
}

if (isset($_GET['page']) && ( $_GET['page'] == 'wprs' ) ) {
	add_action('init', 'wprs_admin_styles');
}

