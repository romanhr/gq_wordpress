<?php
/*
 WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
 this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


add_action('wp_footer', 'wprs_footer_details', 99);
// plugin details
function wprs_footer_details() {
	
	$data = "\n<!--\n	This site is optimized with the " . WPRICHSNIPPETS_PLUGINNAME . " version " . WPRICHSNIPPETS_VER . " by http://authorhreview.com \n";
	
	// if it's a singlar WP Rich Snippets is enabled 
	if ( is_singular() ) {
		
		global $post, $wprs_prefix;
		
		if (wprs_is_enabled($post->ID)) {
			
			// get template details
			$template = wprs_template();
   
			$data .= "		Snippets type	: ".$template['snippets_type']."\n";
			$data .= "		Review type	: ".$template['review_type']."\n";
		}
	}
	
	$data .= " -->\n";
	
	echo $data;

}
