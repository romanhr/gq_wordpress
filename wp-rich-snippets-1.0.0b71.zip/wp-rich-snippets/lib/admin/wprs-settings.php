<?php
	
	/**********************************************************************
    	settings
    /**********************************************************************/
	
	// Prevent loading this file directly - Busted!
	if ( ! class_exists( 'WP' ) )
	{
		header( 'Status: 403 Forbidden' );
		header( 'HTTP/1.1 403 Forbidden' );
		exit;
	}
	
	global $domain;
	$domain = WPRS_LK_CleanTheDomain(get_site_url());
	
    function wprs_settings_init() {
        register_setting('wprs_settings_license_group', 'wprs_license_option','wprs_sanitize_license_settings');
        register_setting('wprs_settings_group', 'wprs_options', 'wprs_sanitize_plugin_settings');
		register_setting('wprs_plugin_options', 'wprs_options', 'wprs_sanitize_validate_options');
    }
    add_action('admin_init', 'wprs_settings_init');
    add_action('init','wprs_check_active');

    function wprs_sanitize_license_settings($options){
        if(isset($options['key'])){            
			global $domain;
            $key = str_replace(" ", "", $options['key']);
            $email = str_replace(" ", "", $options['email']);
            $args = array('body'=>array('key'=>$key,'email'=>$email,'domain'=>$domain));
            $response = wp_remote_post('http://authorhreview.com/?keycheck=yes',$args);
			//print_r($response);
            $returnvalue = wp_remote_retrieve_header($response,'returnvalue');
            if(is_wp_error($response) || !$returnvalue){
                add_settings_error('validate','validate','Could not validate the plugin. Please check the values again');
                return $options;
            }
            $options['validation_value'] = $returnvalue;
        } 
        return $options;
    }
	
    function wprs_sanitize_plugin_settings($options){
        if(isset($_POST['reset'])){
            delete_option('wprs_license_option');
			delete_option('wprs_options');
        }
        return $options;
    }
	
    function wprs_add_admin_validation_page() {
        
		if ( is_admin() && current_user_can('manage_options') ) {
			
			add_menu_page(	__('Rich Snippets', 'wprs'),
							__('Rich Snippets', 'wprs'),
							'administrator',
							'wprs',
							'wprs_admin_validation_page',
							plugin_dir_url( WPRICHSNIPPETS_IMG_URL.'dash-icon.png' , __FILE__ ).'dash-icon.png'
						);
						
			add_submenu_page('wprs',
							__('Manage License', 'wprs'),
							__('Manage License', 'wprs'),
							'manage_options',
							'wprs',
							'wprs_admin_validation_page'
						);
			
			add_submenu_page('wprs',
							__('Blog News', 'wprs'),
							__('Blog News', 'wprs'),
							'manage_options',
							'wprs-news',
							'wprs_display_news_page'
						);
		}
    }
   
    function wprs_add_plugin_admin_page(){		
		
		if ( is_admin() && current_user_can('manage_options') ) {
			
			add_menu_page(	__('Rich Snippets', 'wprs'),
							__('Rich Snippets', 'wprs'),
							'administrator',
							'wprs',
							'wprs_options_page',
							plugin_dir_url(  WPRICHSNIPPETS_IMG_URL.'dash-icon.png' , __FILE__ ).'dash-icon.png'
						);
			
			add_submenu_page('wprs', 
							__('Plugin Settings', 'wprs'), 
							__('Settings', 'wprs'),
							'manage_options', 
							'wprs', 
							'wprs_options_page');
			
			add_submenu_page('wprs',
							__('List All', 'wprs'), 
							__('List All', 'wprs'), 
							'manage_options',
							'wprs-list',
							'wprs_render_list_page'
						);

			add_submenu_page('wprs',
							__('Blog News', 'wprs'), 
							__('Blog News', 'wprs'),
							'manage_options',
							'wprs-news',
							'wprs_display_news_page'
						);
			
			add_submenu_page('wprs', 
							__('import / export', 'wprs'), 
							__('Import / Export', 'wprs'),
							'manage_options', 
							'wprs-import-export', 
							'wprs_import_export_page');
		}
    }


    function wprs_admin_validation_page() {
		echo '<div class="wrap">';
		wprs_screen_icon();
		echo '<h2>'.WPRICHSNIPPETS_PLUGINNAME.' '.__('Settings','wprs').' <span style="font-size:10px;">'.__('Ver','wprs').' '. WPRICHSNIPPETS_VER.'</span></h2>';
		//echo '<p>Get more control over Google SERPs.</p>';
		global $domain;
		$options = get_option('wprs_license_option');
        if(wprs_compare_validation()){
            echo 'thanks for activating';
        } else { ?>
		<form method="post" action="options.php">
		<?php
			settings_fields('wprs_settings_license_group');
			settings_errors();
		?>
        <table class="form-table">
		
        <tr>
			<th><label for="licensekey"><?php _e('API key'); ?></label></th>
			<td>
            	<input id="wprs_license_option[key]" class="regular-text" type="text" name="wprs_license_option[key]" value="<?php echo str_replace(" ", "", $options['key']); ?>">
            	<br>
				<span class="description"><?php _e('Do not have one? <a href="http://authorhreview.com/profile/" target="_blank">get it here</a>'); ?></span>
			</td>
		</tr>
        
        <tr>
			<th><label for="licenseemail"><?php _e('Your email'); ?></label></th>
			<td>
            	<input id="wprs_license_option[email]" class="regular-text" type="text" name="wprs_license_option[email]" value="<?php echo str_replace(" ", "", $options['email']); ?>">
            	<br>
				<span class="description"><?php _e('Enter the email you used to register this plugin'); ?></span>
			</td>
		</tr>
        
        <tr>
			<th><label for="licensedomain"><?php _e('Your Domain'); ?></label></th>
			<td>
            	<input readonly="readonly" id="wprs_license_option[domain]" class="regular-text" type="text" name="wprs_license_option[domain]" value="<?php echo $domain ?>">
            	<br>
				<span class="description"><?php _e('You do not have to enter this, we got it!'); ?></span>
			</td>
		</tr>
        
	</table>
        
 
        
        <br />
        <input type="submit" class="button-primary lk_key" value="<?php _e('Validate') ?>">
    </form> 
    
    
    <?php } ?>
        
	</div><!-- end of admin page wrap -->

<?php
    }
    
	
    function wprs_check_active(){      
        if(wprs_compare_validation()){
			add_action( 'admin_menu',									'wprs_add_plugin_admin_page'	); 
			add_action( 'admin_menu',									'wprs_documentation_menu'		); 
			add_action( 'admin_menu',									'wprs_support_menu'				);
			add_action( 'admin_print_styles-post-new.php',				'wprs_enqueue'					);
			add_action( 'admin_print_styles-post.php',					'wprs_enqueue'					);
			add_action(	'admin_footer',									'wprs_raty_scripts'				);
			add_action( 'admin_menu',									'wprs_add_box'					);
			add_action( 'save_post',									'wprs_save_data'				);
			
			global $pagenow;
			
        } else {
            add_action('admin_menu',	'wprs_add_admin_validation_page' ); // the function to show the activation page
            add_action('admin_notices'	,create_function(''," echo \"<div class='update-nag'>".__('Please Validate the')." <a href='".admin_url().'admin.php?page=wprs'."'>".__(WPRICHSNIPPETS_PLUGINNAME)."</a> plugin!</div>\";"));

        }
    }
    

    function wprs_compare_validation(){
        $options = get_option('wprs_license_option');
        if(isset($options['validation_value'])){
            $register_email = str_replace(" ", "", $options['email']);
            $key = str_replace(" ", "", $options['key']);
			$domain = $options ['domain'];
			//global $domain;
            $validation_value = $options['validation_value'];
            $checkvalue = md5($register_email . $key . $domain);
            if($checkvalue == $validation_value){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
	
	
	function WPRS_LK_CleanTheDomainxx($url) {
		
		// Remove the http://, www., and slash(/) from the URL 
		// If URI is like, eg. www.way2tutor	ial.com/
		$input = trim($url, '/');

		// If not have http:// or https:// then prepend it
		//if (!preg_match('#^http(s)?://#', $input)) {
		//    $input = 'http://' . $input;
		//}
		$urlParts = parse_url($input);

		// Remove www.
		$domain_name = preg_replace('/^www\./', '', $urlParts['host']);
		
		if(!empty($domain_name)) {
			return $domain_name;
     	}
		else {
			return false;
		}
		
		/*
		$nowww = preg_replace('www\.','',$url);
		$domain = parse_url($nowww);
		
		if(!empty($domain["host"])) {
			return $domain["host"];
     	}
		else {
			return $domain["path"];
		}
 		*/
	}
	
	function WPRS_LK_CleanTheDomain($url) {
		$input = trim($url, '/');
		$urlParts = parse_url($input);
		$domain_name = preg_replace('/^www\./', '', $urlParts['host']);
		if(!empty($domain_name)) {
			return $domain_name;
     	}
		else {
			return false;
		}
	}

	function wprs_add_defaults() {
		$tmp= get_option('wprs_options');
    	if((isset($tmp['wprs_chk_default_options_db'])=='1')||(!is_array($tmp))) {
			delete_option('wprs_options');
			$arr = array();
			update_option('wprs_options', $arr);
		}
	}


	function wprs_sanitize_validate_options($input) {
		//$input['wprs_box_width'] =  wp_filter_nohtml_kses($input['wprs_box_width']);
        if(isset($_POST['reset'])){
			delete_option('wprs_license_option');
		}
		return $input;
	}


	function wprs_support_menu() {
    	global $submenu;
			$submenu['wprs'][504] = array(
													'Support',
													'administrator' ,
													'http://authorhreview.com/support/forums/plugins-support/wprs-reviews-plugin/'
											);
	}

	function wprs_documentation_menu() {
    	global $submenu;
			$submenu['wprs'][604] = array(
													'Documentation',
													'administrator' ,
													'http://authorhreview.com/docs/all/'
											);
	}
	
	add_action( 'admin_footer', 'wprs_add_target_blank_to_support_menu_item');
	
	function wprs_add_target_blank_to_support_menu_item() { ?>
    		<script type="text/javascript"> jQuery(document).ready(function($) {
				$('.wprs-submenu-wrap li a[href*="authorhreview.com/support"]').attr('target', '_blank');
				$('.wprs-submenu-wrap li a[href*="authorhreview.com/docs"]').attr('target', '_blank');});
			</script>
            <?php

	}



	// ------------------------------------------------------------------------
	// screen icon
	// ------------------------------------------------------------------------
	function wprs_screen_icon () {
		echo '<div id="wprs-options" class="icon32 wprs_icon32" id=""></div>';
	}


	// ------------------------------------------------------------------------
	// admin links
	// ------------------------------------------------------------------------
	function wprs_admin_links() { ?>
	
        <div class="wprs_admin_link">
            <ul>
				<li><p>
                	<a href="http://wordpress.org/extend/plugins/author-hreview/" target="_blank"><p>Rate the plugin 5<span class="icon-star"></span> on WordPress.org</p></a></p>
				</li>
                <li class="wprs_blog"><p>
                	<a href="http://authorhreview.com/" title="Author hReview Plugin for WordPress" target="_blank"><p>Blog about it and link to the plugin site</p></a></p>
				</li>
                
                <li class="wprs_testimonials"><p>
                		<a href="http://authorhreview.com/about/send-testimonial/" title="Send a Testimonial" target="_blank">
                    		Send a Testimonial</a> (& probably get featured)
					</p>
				</li>
                
                <li class="wprs_affiliate"><p>
                		<a href="http://authorhreview.com/member/aff/aff" title="Affiliate Program" target="_blank">
                    		Get your affiliate link</a> (earn 33% commission)
					</p>
				</li>
			</ul>              
 		</div>
<?php
	}
