<?php
/*
	WP Rich Snippets - Pros shortcode
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	
	// add shortcode
	add_shortcode('wprs-pros', 'wprs_pros_shortcode');
	
	function wprs_pros_shortcode($atts) {
		
		extract(shortcode_atts(array(
        ), $atts));
		
		$conten = '';
		
		global $post, $wprs_prefix;
		
		if ( wprs_is_enabled($post->ID) && !is_front_page() && !is_home() && !is_archive() ) {
			
			$pros = get_post_meta( $post->ID, $wprs_prefix.'pros', true ) ? get_post_meta( $post->ID, $wprs_prefix.'pros', true ) : '';
		
			$content = '<div class="wprs_pros">';
			$content .= '<h3><i class="fa fa-thumbs-up"></i> '. __('Pros', 'wprs') .'</h3>';
			$content .= '<p>' . $pros . '</p>';
			$content .= '</div>';
		}
		
		return $content;
	}
