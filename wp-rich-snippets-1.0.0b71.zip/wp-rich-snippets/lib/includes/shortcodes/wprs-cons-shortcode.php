<?php
/*
	WP Rich Snippets - Cons shortcode
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	
	// add shortcode
	add_shortcode('wprs-cons', 'wprs_cons_shotrcode');
	
	function wprs_cons_shotrcode($atts) {
		
		extract(shortcode_atts(array(
        ), $atts));
		
		$conten = '';
		
		global $post, $wprs_prefix;
		
		if ( wprs_is_enabled($post->ID) && !is_front_page() && !is_home() && !is_archive() ) {
			
			$cons = get_post_meta( $post->ID, $wprs_prefix.'cons', true ) ? get_post_meta( $post->ID, $wprs_prefix.'cons', true ) : '';
		
			$content = '<div class="wprs_cons">';
			$content .= '<h3><i class="fa fa-thumbs-down"></i> '. __('Cons', 'wprs') .'</h3>';
			$content .= '<p>' . $cons . '</p>';
			$content .= '</div>';
		}
		
		return $content;
	}
