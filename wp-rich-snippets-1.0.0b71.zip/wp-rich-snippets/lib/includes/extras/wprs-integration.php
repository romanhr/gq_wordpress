<?php
/*
	integrations that is required by the plugin
	
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
    */
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	


	/*
    	Views plugin integration
		use shortcode [wprs-raw-content] to replace wpr-raw-content
		this to avoid duplicate rating box when using Views
		@since 1.0.0
    	*/
	add_shortcode('wprs-raw-content', 'wprs_raw_content_shortcode');
		function wprs_raw_content_shortcode() {
		global $post;
		return wpautop(wptexturize(do_shortcode($post->post_content)));
	}
	
	
	
	/*
		try to disable Disqus comments on aggregate 
		@since 1.0.0
		*/
	function wprs_disable_disqus($file) {
		global $post;
		
		// get type
		$type = wprs_get_type();

		/**
 		* Detect plugin. For use on Front End only.
 		*/
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		$plugin = 'disqus-comment-system/disqus.php';
		// check for plugin using plugin name
		if ( is_plugin_active( $plugin ) ) {
  			// disqus is active
  			// remove disqus filter
			remove_filter('comments_template', 'dsq_comments_template');
			// if WPRS is not enabled, or it's not an aggregate review... add back disqus filter
			if (!wprs_is_enabled($post->ID) || $type != 'aggregate')	add_filter('comments_template', 'dsq_comments_template');
		}
		// return regular comments template
		return $file;
	}
	add_filter( 'comments_template' , 'wprs_disable_disqus', 1 );
	
