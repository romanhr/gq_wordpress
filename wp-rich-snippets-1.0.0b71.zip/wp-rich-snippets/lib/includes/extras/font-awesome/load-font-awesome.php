<?php
	/* 
	load font awesome
	*************************/
   
class WPARS_FontAwesome {
    public function __construct() {
        add_action( 'init', array( &$this, 'init' ) );
    }

    public function init() {
        add_action( 'wp_enqueue_scripts', array( $this, 'register_plugin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'register_plugin_styles' ) );
        //add_shortcode( 'icon', array( $this, 'setup_shortcode' ) );
        //add_filter( 'widget_text', 'do_shortcode' );
    }

    public function register_plugin_styles() {
        global $wp_styles;
		$options = get_option('wprs_options');
		if ( isset($options['wprs_no_fontawesome']) != true ) {
        	//wp_enqueue_style( 'font-awesome', WPRS_INC_URL.'font-awesome/assets/css/font-awesome.min.css', array(), '4.0.3', 'all' );
        	//wp_enqueue_style( 'font-awesome-ie7', WPRS_INC_URL.'font-awesome/assets/css/font-awesome-ie7.min.css', array(), '4.0.3', 'all' );
			
			wp_enqueue_style( 'font-awesome', WPRS_INC_URL.'extras/font-awesome/assets/css/font-awesome.min.css');
        	//wp_enqueue_style( 'font-awesome-ie7', WPRS_INC_URL.'extras/font-awesome/assets/css/font-awesome-ie7.min.css');
			
        	$wp_styles->add_data( 'font-awesome-ie7', 'conditional', 'lte IE 7' );
		}
    }

    /*public function setup_shortcode( $params ) {
        extract( shortcode_atts( array(
                    'name' => 'icon-wrench'
                ), $params ) );
        $icon = '<i class="'.$params['name'].'">&nbsp;</i>';

        return $icon;
    }*/

}

new WPARS_FontAwesome();

