<?php
/*
	Global filters that is required by the plugin
	
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
    */
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	
	
	add_filter('wprs_content_after','wprs_do_pros_and_cons');
	/*
		do cons & pros
		@since 1.0.0
		*/
	function wprs_do_pros_and_cons() {
		global $post;
		$pros = wprs_pros($post->ID);
		$cons = wprs_cons($post->ID);
		return $pros . $cons;
	}

