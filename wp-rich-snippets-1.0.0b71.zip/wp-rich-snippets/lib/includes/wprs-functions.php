<?php
/*
	Global functions that is required by the plugin
	
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
    */
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	
	
	/*
    	check if WP Rich Snippets is enabled on an entry, example wprs_is_enabled($id);
		@since 1.0.0
    	*/
	function wprs_is_enabled($id) {
		global $wprs_prefix;
		if ( get_post_meta($id, $wprs_prefix.'snippets_types', TRUE) == null )	{ 
			return '';
		} else {
			return true;
		}
	}
	
	
	/*
		get post meta
		scan meta data, and return an array of values
		@since 1.0.0
		*/
	function wprs_get_meta() {
		global $post, $wprs_prefix;

		//if (is_admin()) return;
		
		$custom_fields = get_post_custom( $post->ID );
		
		$wprs_array = array();
		
		foreach ( $custom_fields as $key => $fields ) {
    		if ( strpos( $key, $wprs_prefix ) !== false ) {
        		if ( isset( $fields[0] ) ) {
					$wprs_array[$key] = $fields[0];
        		}
    		}
		}

		// debug
		// echo '<pre>';
		// var_dump($wprs_array);
		// var_dump($custom_fields);
		// echo '</pre>';
		
		return $wprs_array;
	}
	
	
	/*
		get entry type
		scan meta data, and return the type
		@since 1.0.0
		*/
	function wprs_get_type() {
		global $post, $wprs_prefix;
		$type = get_post_meta( $post->ID, $wprs_prefix.'review_type', true ) ? get_post_meta( $post->ID, $wprs_prefix.'review_type', true ) : '';
		return $type;
	}
	
		/*
		get entry type by post id
		scan meta data, and return the type
		@since 1.0.0
		*/
	function wprs_get_type_by_id($id) {
		global $wprs_prefix;
		$type = get_post_meta( $id, $wprs_prefix.'review_type', true ) ? get_post_meta( $id, $wprs_prefix.'review_type', true ) : '';
		return $type;
	}
	

	/*
    	check if logged in user is review author, example wprs_is_user_author();
		@since 1.0.0
		*/
	function wprs_is_user_author() {
		global $post, $current_user;	
		get_currentuserinfo();
		if ($post->post_author == $current_user->ID) {return true;} else {return false;}
	}
	
		
	/*
		get author
		@since 1.0.0
	*/
	function wprs_get_author() {
		global $post;
		$author_id = $post->post_author;
		$author = get_the_author_meta( 'display_name', $author_id );
		return $author;
	}
	
	
	/*
    	return author name with itemprop author, example: wprs_author_name_person($id);
		@since 1.0.0
		*/
	function wprs_get_author_name_person($id, $author) {
		global $wprs_prefix;
		$content = '';
		// get the author name
		if (get_post_meta($id, $wprs_prefix.'author_name', TRUE) !='') {
			$review_author = get_post_meta($id, $wprs_prefix.'author_name', TRUE);
		} else {
			 $review_author = $author;
		}
		$content .= __('Reviewed by:', 'wprs') . ' ';
		$content .= '<span itemprop="author" itemscope itemtype="http://schema.org/Person">';
		$content .= '<span class="reviewer byline vcard hcard">';
		$content .= '<span class="me fn" itemprop="name">' . $review_author .'</span>';
		$content .= '</span>';
		$content .= '</span>';
		return $content;
	}
	
	
	/*
    	get description, example wprs_get_description($id);
		@since 1.0.0
		*/
	function wprs_get_description($id) {
		global $wprs_prefix;
		$desc = '<h4>' . __('Description', 'wprs') . ': '.wprs_get_disclaimer($id).'</h4>';
		$desc .= '<div class="description" itemprop="description">';
		$desc .= '<p>' . get_post_meta($id, $wprs_prefix.'item_description', TRUE) . '</p>';
		$desc .= '</div>';
		return $desc;
	}
	

	/*
		get Paid Review Disclaimer, example: wprs_get_disclaimer($id)
		used in wprs_get_description() function
		@since 1.0.0.0
		*/
	function wprs_get_disclaimer($id) {
		global $wprs_prefix;
		$options = get_option('wprs_options');
		$custom = get_post_custom($id);
		if (get_post_meta($id, $wprs_prefix.'disclaimer_enable', TRUE) == null ) return '';
		$disclaimer_title = $options['wprs_disclaimer_title'];
		$disclaimer_url = $options['wprs_disclaimer_url'];
		if ( !$disclaimer_url ) return '';
		return '<span class="wprs_disclaimer"><a href="'.$disclaimer_url.'" title="Disclaimer"><span class="fa fa-exclamation-circle"></span> '.$disclaimer_title.'</a></span>';
	}
	

	/*
    	return published date, example: wprs_get_dtreviewed();
		@since 1.0.0
		*/
	function wprs_get_dtreviewed() {
		$content = '';
		$content .= '<div>' . __('Published on', 'wprs') . ': <span class="dtreviewed rating_date">';
		$content .= '<span itemprop="datePublished" class="" title="' . get_the_time(get_option('date_format')) . '">' . get_the_time(get_option('date_format'));
		$content .= '</span></span>';
		$content .= '</div>';
		return $content;
	}
	
	
	/*
    	return modified date, example: wprs_get_dtmodified();
		@since 1.0.0
		*/
	function wprs_get_dtmodified() {
		$content = '';
		$content .= '<div>' . __('Last modified', 'wprs') . ': ';
		$content .= '<span class="dtmodified updated rating_date" itemprop="dateModified">';
		$content .= '<span title="'. get_the_modified_time(get_option('date_format')) . '">' . get_the_modified_time(get_option('date_format')) . '</span></span>';
		$content .= '</div>';
		return $content;
	}
	
	
	/*
    	return user aggregate rating stars with no markups, example wprs_get_userrating_stars($post_id);
		@since 1.0.0
    	*/
	function wprs_get_userrating_stars($post_id) {
		global $wprs_prefix;
		$count = get_post_meta( $post_id, $wprs_prefix.'userrating_count', true ) ? get_post_meta( $post_id, $wprs_prefix.'userrating_count', true ) : 0;
		$rating = get_post_meta( $post_id, $wprs_prefix.'userrating_average', true ) ? get_post_meta( $post_id, $wprs_prefix.'userrating_average', true ) : 0;
		$rating_round = strval( (round($rating * 2) / 2) );
		$content = '<span class="sr-only">'. __('Rated', 'wprs').' '.$rating.' '. __('stars', 'wprs').'</span>';
		$rating_display = str_replace('.', '', $rating_round);
		$content .= '<span class="rating rating-user r-'.$rating_display.'" title="'. __('Rated', 'wprs') .' '. $rating . '"></span>';
		$content .= '<br />';
		$content .= '<span><span id="wprs_user_rating">'.$rating.'</span> / 5 <nobr>(<span id="wprs_user_rating_count">'.strip_tags( $count ).'</span> <span class="hidden-xs">'.__('Reviewers', 'wprs').'</span>)</nobr></span>';
		$content .= '</span>';
		return $content;
	}
	
	/*
    	return star rating, example wprs_get_star_rating($rating);
		@since 1.0.0
    	*/
	function wprs_get_star_rating($rating) {
		$content = '<span class="sr-only">'. __('Rated', 'wprs').' '.$rating.' '. __('stars', 'wprs').'</span>';
		$content .= '<span itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">';
		$content .= '<meta content="1" itemprop="worstRating">';
		$content .= '<meta content="' . $rating . '" itemprop="ratingValue">';
		$content .= '<meta content="5" itemprop="bestRating">';
		$rating_display = str_replace('.', '', $rating);
		$content .= '<span class="rating r-'.$rating_display.'" title="'. __('Rated', 'wprs') .' '. $rating . '"></span>';
		$content .= '</span>';
		return $content;
	}
	
	
	/*
    	return user star rating, example wprs_get_user_star_rating($post_id);
		@since 1.0.0
    	*/
	function wprs_get_user_star_rating($post_id) {
		global $wprs_prefix;
		$count = get_post_meta( $post_id, $wprs_prefix.'user_rating_count', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating_count', true ) : 0;
		$rating = get_post_meta( $post_id, $wprs_prefix.'user_rating', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating', true ) : 0;
		$rating_round = strval( (round($rating * 2) / 2) );
		$content = '<span class="sr-only">'. __('Rated', 'wprs').' '.$rating.' '. __('stars', 'wprs').'</span>';
		$content .= '<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">';
		$content .= '<meta content="1" itemprop="worstRating">';
		$content .= '<meta content="' . $rating . '" itemprop="ratingValue">';
		$content .= '<meta content="5" itemprop="bestRating">';
		$rating_display = str_replace('.', '', $rating_round);
		$content .= '<span class="rating rating-user r-'.$rating_display.'" title="'. __('Rated', 'wprs') .' '. $rating . '"></span>';
		$content .= '<br />';
		$content .= '<span><span id="wprs_user_rating">'.$rating.'</span> / 5 (<span itemprop="ratingCount" id="wprs_user_rating_count">'.strip_tags( $count ).'</span> <span class="hidden-xs">'.__('Reviewers', 'wprs').'</span>)</span>';
		$content .= '</span>';
		return $content;
	
	}

	/*
    	return user aggregate rating, example wprs_get_user_star_rating_aggregate($post_id);
		@since 1.0.0
    	*/
	function wprs_get_user_star_aggregate($post_id) {
		global $wprs_prefix;
		$count = get_post_meta( $post_id, $wprs_prefix.'userrating_count', true ) ? get_post_meta( $post_id, $wprs_prefix.'userrating_count', true ) : 0;
		$rating = get_post_meta( $post_id, $wprs_prefix.'userrating_average', true ) ? get_post_meta( $post_id, $wprs_prefix.'userrating_average', true ) : 0;
		$rating_round = strval( (round($rating * 2) / 2) );
		$content = '<span class="sr-only">'. __('Rated', 'wprs').' '.$rating.' '. __('stars', 'wprs').'</span>';
		$content .= '<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">';
		$content .= '<meta content="1" itemprop="worstRating">';
		$content .= '<meta content="' . $rating . '" itemprop="ratingValue">';
		$content .= '<meta content="5" itemprop="bestRating">';
		$rating_display = str_replace('.', '', $rating_round);
		$content .= '<span class="rating rating-user r-'.$rating_display.'" title="'. __('Rated', 'wprs') .' '. $rating . '"></span>';
		$content .= '<br />';
		$content .= '<span><span id="wprs_user_rating">'.$rating.'</span> / 5 (<span itemprop="reviewCount" id="wprs_user_rating_count">'.strip_tags( $count ).'</span> <span class="hidden-xs">'.__('Reviewers', 'wprs').'</span>)</span>';
		$content .= '</span>';
		return $content;
	}
	
	
	/*
    	return editor/user rating percentage, example wprs_get_progressbar($slider_percentage, $ratingsource = 'editor');
		@since 1.0.0
		*/
	function wprs_get_progressbar($slider_percentage, $ratingsource = 'editor') {
		$content = '';
		if(!isset($slider_percentage)) return '';
		
		$content .= '<div class="progress">';
		$content .= '<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="'.$slider_percentage.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$slider_percentage.'%;">';
		$content .= '<span class="sr-only"'. __('Rated', 'wprs').$slider_percentage.'%</span>';
		$content .= '</div>';
		$content .= '</div>';	
		return $content;
	}
	
	
	/*
    	return editor/user rating percentage, example wprs_get_rating_percentage($rating, $ratingsource);
		@since 1.0.0
		*/
	function wprs_get_rating_percentage($rating, $ratingsource = 'editor', $percentage = false) {
		$content = '';
		if(!isset($rating)) return '';
		if (!$percentage) $rating =  ($rating / 5) * 100;
		if ($ratingsource == 'editor') {
			$content = '<span itemprop="reviewRating" class="editorrating_average"><span>' . $rating .'%</span></span>';
		} else {
				$content = '<span class="userrating_average"><span>' . $rating .'%</span></span>';
		}
		return $content;
	}
	
	
	/*
    	return item name, example: wprs_item_name($id);
		@since 1.0.0
		*/
	function wprs_get_item_name($id) {
		global $wprs_prefix;
		$content = '';
		//check if there is a url link
		if (get_post_meta($id, $wprs_prefix.'item_url', TRUE)) {
			$content .= '<a rel="nofollow" href="' . get_post_meta($id, $wprs_prefix.'item_url', TRUE) .'" title="' . get_post_meta(id, $wprs_prefix.'item_name', TRUE) .'"'.wprs_getWindowTarget().wprs_getDofollow($id).'>' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '</a>';
		} else {
			// if there is no url link, just print the name
			$content .= get_post_meta($id, $wprs_prefix.'item_name', TRUE);
		}
		return $content;
	}


	/*
    	return item name, example: wprs_item_name($id);
		@since 1.0.0
		*/
	function wprs_get_itemprop_name($id) {
		global $wprs_prefix;
		$content = '';
		//check if there is a url link
		if (get_post_meta($id, $wprs_prefix.'item_url', TRUE)) {
			$content .= '<span itemprop="name">';
			$content .= '<a rel="nofollow" href="' . get_post_meta($id, $wprs_prefix.'item_url', TRUE) .'" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) .'"'.wprs_getWindowTarget().wprs_getDofollow($id).'>' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '</a>';
			$content .= '</span>';
		} else {
			// if there is no url link, just print the name
			$content .= '<span itemprop="name">';
			$content .= get_post_meta($id, $wprs_prefix.'item_name', TRUE);
			$content .= '</span>';
		}
		return $content;
	}
	
	
	/*
    	return item name wraped in Thing schema, example: wprs_get_Thing($id);
		@since 1.0.0
		*/	
	function wprs_get_Thing($id) {
		global $wprs_prefix;
		$content = '';
		if (get_post_meta($id, $wprs_prefix.'item_name', TRUE) !='') {
			//check if there is a url link
			if (get_post_meta($id, $wprs_prefix.'item_url', TRUE)) {
				$content .= '<span class="item title fn" itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">';
				$content .= '<a rel="nofollow" href="' . get_post_meta($id, $wprs_prefix.'item_url', TRUE) .'" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) .'"'.wprs_getWindowTarget().wprs_getDofollow($id).'><span itemprop="name">' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '</span></a>';
				$content .= '</span>';
			} else {
				// if there is no url link, just print the name
				$content .= '<span class="item title fn" itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">';
				$content .= '<span itemprop="name">'.get_post_meta($id, $wprs_prefix.'item_name', TRUE).'</span>';
				$content .= '</span>';
			}
		}
		return $content;
	}
	
	
	/*
    	return phone
		@since 1.0.0
		*/
	function wprs_get_phone($id) {
		global $wprs_prefix;
		$phone = '';
		$phone_number = get_post_meta($id, $wprs_prefix.'telephone', TRUE) ? get_post_meta($id, $wprs_prefix.'telephone', TRUE) : '';
		if ($phone_number) $phone = '<span itemprop="telephone"><i class="fa fa-phone"></i> '.$phone_number.'</span>';
		return $phone;

	}
	
	/*
    	return address
		@since 1.0.0
		*/
	function wprs_get_address($id) {
		global $wprs_prefix;
		
		$meta = wprs_get_meta();
		$address = '';
		$spacer = ' ';
		$s_spacer = ', ';
		
		$streetAddress = isset($meta[$wprs_prefix.'streetAddress']) ? $meta[$wprs_prefix.'streetAddress'] : '';
		$postOfficeBoxNumber = isset($meta[$wprs_prefix.'postOfficeBoxNumber']) ? $meta[$wprs_prefix.'postOfficeBoxNumber'] : '';
		$addressLocality = isset($meta[$wprs_prefix.'addressLocality']) ? $meta[$wprs_prefix.'addressLocality'] : '';
		$addressRegion = isset($meta[$wprs_prefix.'addressRegion']) ? $meta[$wprs_prefix.'addressRegion'] : '';
		$postalCode = isset($meta[$wprs_prefix.'postalCode']) ? $meta[$wprs_prefix.'postalCode'] : '';
		$addressCountry = isset($meta[$wprs_prefix.'addressCountry']) ? $meta[$wprs_prefix.'addressCountry'] : '';
		
		// if streetAddress is empty, return!
		if ($streetAddress == '') return '';
		
		// put it all together
		$address = '<div class="wprs_address" itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">';
		$address .= '<i class="fa fa-map-marker"></i> ';
		if ($streetAddress != '') {$address .= '<span itemprop="streetAddress">'.$streetAddress.'</span>'.$s_spacer;}
		if ($postOfficeBoxNumber != '') {$address .= '<span itemprop="postOfficeBoxNumber">'.$postOfficeBoxNumber.'</span>'.$s_spacer;}
		if ($addressLocality != '') {$address .= '<span itemprop="addressLocality">'.$addressLocality.'</span>'.$s_spacer;}
		if ($addressRegion != '') {$address .= '<span itemprop="addressRegion">'.$addressRegion.'</span>'.$spacer;}
		if ($postalCode != '') {$address .= '<span itemprop="postalCode">'.$postalCode.'</span>'.$s_spacer;}
		if ($addressCountry != '') {$address .= '<span itemprop="addressCountry">'.$addressCountry.'</span>';}
		$address .= '</div>';
		
		return $address;

	}
	
	
	/*
    	return currancy symbol,	transform USA to $
		@since 1.0.0
		*/
	function wprs_get_currency_symbol($code = 'USD') {
		$currencies = array(
			'AED' => array('name' => "United Arab Emirates Dirhams", 'symbol' => "AED", 'ASCII' => ""),
			'AUD' => array('name' => "Australian Dollar", 'symbol' => "A$", 'ASCII' => "A&#36;"),
			'BTC' => array('name' => "Bitcoin", 'symbol' => "฿", 'ASCII' => ""),
			'CAD' => array('name' => "Canadian Dollar", 'symbol' => "CA$", 'ASCII' => ""),
			'CZK' => array('name' => "Czech Koruna", 'symbol' => "Kč", 'ASCII' => ""),
			'DKK' => array('name' => "Danish Krone", 'symbol' => "Kr", 'ASCII' => ""),
			'EUR' => array('name' => "Euro", 'symbol' => "€", 'ASCII' => "&#128;"),
			'HKD' => array('name' => "Hong Kong Dollar", 'symbol' => "$", 'ASCII' => "&#36;"),
			'HUF' => array('name' => "Hungarian Forint", 'symbol' => "Ft", 'ASCII' => ""),
			'IRR' => array('name' => "Iranian Rial", 'symbol' => "﷼", 'ASCII' => ""),
			'INR' => array('name' => "Indian Rupee", 'symbol' => "₹", 'ASCII' => ""),
			'ILS' => array('name' => "Israeli New Sheqel", 'symbol' => "₪", 'ASCII' => "&#8361;"),
			'JPY' => array('name' => "Japanese Yen", 'symbol' => "¥", 'ASCII' => "&#165;"),
			'MXN' => array('name' => "Mexican Peso", 'symbol' => "$", 'ASCII' => "&#36;"),
			'NOK' => array('name' => "Norwegian Krone", 'symbol' => "Kr", 'ASCII' => ""),
			'NZD' => array('name' => "New Zealand Dollar", 'symbol' => "$", 'ASCII' => "&#36;"),
			'PHP' => array('name' => "Philippine Peso", 'symbol' => "₱", 'ASCII' => ""),
			'PLN' => array('name' => "Polish Zloty", 'symbol' => "zł", 'ASCII' => ""),
			'GBP' => array('name' => "Pound Sterling", 'symbol' => "£", 'ASCII' => "&#163;"),
			'SGD' => array('name' => "Singapore Dollar", 'symbol' => "$", 'ASCII' => "&#36;"),
			'SEK' => array('name' => "Swedish Krona", 'symbol' => "kr", 'ASCII' => ""),
			'CHF' => array('name' => "Swiss Franc", 'symbol' => "CHF", 'ASCII' => ""),
			'TWD' => array('name' => "Taiwan New Dollar", 'symbol' => "NT$", 'ASCII' => "NT&#36;"),
			'THB' => array('name' => "Thai Baht", 'symbol' => "฿", 'ASCII' => "&#3647;"),
			'USD' => array('name' => "U.S. Dollar", 'symbol' => "$", 'ASCII' => "&#36;")
		);
		if (!empty($currencies[$code]['ASCII'])) {
			return (string) $currencies[$code]['ASCII'];
		}
		return (string) $currencies[$code]['symbol'];
	}
	
	
	/*
    	return price, example wprs_get_price($id, $currency_sympol);
		@since 1.0.0
		*/
	function wprs_get_price($id, $currency_sympol) {	
		
		global $wprs_prefix;
		
		$options = get_option('wprs_options');
		
		// if price set to hide, then return nothing!
		if (isset($options['wprs_chk_price_hide'])) return;
		
		// if snippets type LocalBusiness, then return nothing (price is not part of schema
		// @since 1.0.0
		if (get_post_meta($id, $wprs_prefix.'snippets_types', TRUE) == 'Organization') return;
		
		// get currency
		$price_content = '';
		$currency = isset($options['wprs_currency']) != '' ? $options['wprs_currency'] : 'USD';
		
		$lowPrice = get_post_meta($id, $wprs_prefix.'lowprice', TRUE) ? get_post_meta($id, $wprs_prefix.'lowprice', TRUE) : '';
		$highPrice = get_post_meta($id, $wprs_prefix.'highprice', TRUE) ? get_post_meta($id, $wprs_prefix.'highprice', TRUE) : '';
			
		if ($lowPrice !='' && $highPrice !='') {
			$price_content = '<span class="price" itemprop="offers" itemscope itemtype="http://schema.org/AggregateOffer">';
			//$lowPrice = get_post_meta($id, $wprs_prefix.'lowprice', TRUE);
			//$highPrice = get_post_meta($id, $wprs_prefix.'highprice', TRUE);
		} else {
			if ($lowPrice !='') {
				$price_content = '<span class="price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">';
			}
		}
		
		if ($lowPrice !='') {
			$price = $lowPrice;
			// check if currency sympol is disabled
			if (isset($options['wprs_chk_currency_symbol_hide'])) {$currency_sympol='';}
			// check price
			if ($price == '0.00' && isset($options['wprs_chk_rating_box_free'])) {
				$price_content .= '<span class="free_price">';
				$price_content .= '<span class="free">'. __('FREE', 'wprs') .'</span>';
				$price_content .= '</span>';
			} else {
				$price_content .= '<span>';
				if ($currency_sympol) $price_content .= '<sup>'.$currency_sympol.'</sup>';
				$price_content .= get_post_meta($id, $wprs_prefix.'lowprice', TRUE);
				$price_content .= '</span>';
			}
		}
		
		if ($highPrice !='') {
			$price = $highPrice;
			// check if currency sympol is disabled
			if (isset($options['wprs_chk_currency_symbol_hide'])) {$currency_sympol='';}
			// check price
			if ($price == '0.00' && isset($options['wprs_chk_rating_box_free'])) {
				$price_content .= '<span class="highprice">';
				$price_content .= '<span class="free_price">'.__('to','wprs').' ';
				$price_content .= '<span class="free">'. __('FREE', 'wprs') .'</span>';
				$price_content .= '</span>';
				$price_content .= '</span>';
			} else {
				$price_content .= '<span class="highprice">';
				$price_content .= '<span>'.__('to', 'wprs').' ';
				if ($currency_sympol) $price_content .= '<sup>'.$currency_sympol.'</sup>';
				$price_content .= $highPrice;
				$price_content .= '</span>';
				$price_content .= '</span>';
			}
		}
			
		if ($lowPrice !='' && $highPrice !='') {
			$price_content .= '<meta itemprop="lowPrice" content="'.$lowPrice.'">';
			$price_content .= '<meta itemprop="highPrice" content="'.$highPrice.'">';
		} else {
			$price_content .= '<meta itemprop="price" content="' . $lowPrice .'">';
			
		}
			
		$price_content .= '<meta itemprop="priceCurrency" content="'.$currency.'" />';
		//$price_content .= '<link itemprop="availability" href="http://schema.org/InStock" /><sup class="in_stock">In stock</sup>';
		$price_content .= '</span>';
		
		// for Restaurant
		if (get_post_meta($id, $wprs_prefix.'snippets_types', TRUE) == 'Restaurant') {
			$price_content = '<span class="price_range_digits">';
			$price_content .= '<span itemprop="priceRange">' . get_post_meta($id, $wprs_prefix.'price_range_digits', TRUE) . '</span>';
			$price_content .= '</span>';
			if ($lowPrice !='' && $highPrice !='') {
				$price_content .= '<span class="price_range">';
				$price_content .= '<span>' . $currency_sympol . $lowPrice . '-' . $highPrice . '</span>';
				$price_content .= '</span>';
			}
			//$price_content .= '</span>';
		}
		
		return $price_content;
		
	}
	
	
	/*
    	return score
		@since 1.0.0
		*/
	function wprs_get_score($rating = '1', $ratingsource = 'editor') {
		
		$scores = array(
			'1'		=> array(	'score' => __('Really Bad', 'wprs'),	'icon' => "fa fa-thumbs-down"),
			'1.5'	=> array(	'score' => __('Bad', 'wprs'),			'icon' => "fa fa-thumbs-down"),
			'2'		=> array(	'score' => __('Poor', 'wprs'),			'icon' => "fa fa-thumbs-down"),
			'2.5'	=> array(	'score' => __('OK', 'wprs'),			'icon' => "fa fa-thumbs-up"),
			'3'		=> array(	'score' => __('Good', 'wprs'),			'icon' => "fa fa-thumbs-up"),
			'3.5'	=> array(	'score' => __('Very Good', 'wprs'),		'icon' => "fa fa-thumbs-up"),
			'4'		=> array(	'score' => __('Excellent', 'wprs'),		'icon' => "fa fa-thumbs-up"),
			'4.5'	=> array(	'score' => __('Outstanding', 'wprs'),	'icon' => "fa fa-thumbs-up"),
			'5'		=> array(	'score' => __('Spectacular', 'wprs'),	'icon' => "fa fa-thumbs-up"),
		);
		
		$output = '';
		
		if ($ratingsource == 'editor' && $rating != 0) {
			$rating = strval( (round($rating * 2) / 2) );
			$output = '<span class="'.$scores[$rating]['icon'].'"></span><span class="hidden-xs"> '.$scores[$rating]['score'].'</span>';
		}
		if ($ratingsource == 'user' && $rating != 0) {
			$rating = strval( (round($rating * 2) / 2) );
			$output = '<span class="'.$scores[$rating]['icon'].'"></span><span class="hidden-xs"> '.$scores[$rating]['score'].'</span>';
		}
		return $output;
	}
	
	
	/*
    	criteria, example: wprs_get_criteria($id, $type);
		$type = (editr, user, all)
		@since 1.0.0
		*/
	function wprs_get_criteria($id, $source_type='editor'){
		
		global $wprs_prefix;
		
		if (get_post_meta($id, $wprs_prefix.'repeatable', TRUE)) {
			$myarray = get_post_meta($id, $wprs_prefix.'repeatable', TRUE);
			//if (!isset($source_type)) $source_type = '';
			$criteria = '<ul>';
				foreach($myarray as $key => $element){
					$criteria .= '<li>';
					$criteria .= '<div class="row">';
					$criteria .= '<div class="col-md-6 progress_title">';			
						// check if desc is presented,
						// if not, then use title instead
						// modified to check editor/user rating
						// @since 1.0.0
						//if ( get_post_meta($id, $wprs_prefix.'star_rating', TRUE) != null || get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE)) {
							if ($element['desc'] !== '') {
								$criteria .= '<span title="'.$element['desc'].'">'.$element['desc'].'</span>';
							} else {
								$criteria .= '<span title="'.$element['title'].'">'.$element['title'].'</span>';
							}
						//}
						$criteria .= '</div>';
						$rating_display = $element['rating'];
						if ($element['rating'] !='No Rating') {
							// editor criteria
							// display only if author rating is not empty
							// @since 1.0.0
									
							// open span
							$criteria .= '<div class="col-md-6">';
							// editor criteria
							//if (get_post_meta($id, $wprs_prefix.'star_rating', TRUE) != null) {
								if ($source_type == 'editor' || $source_type == 'all') {
									$criteria .= '<div class="progress">';
									$criteria .= '<div class="progress-bar progress-bar-warning" role="progressbar" title="'.$rating_display.'%" aria-valuenow="'.$rating_display.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$rating_display.'%">';
									$criteria .= '<span class="sr-only">'. __('Editor', 'wprs').': '.$rating_display.'%</span>';
									$criteria .= '</div>';
									$criteria .= '</div>';
								}
							//}
							// user criteria
							if (get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE)) {				
								$user_rating_display = get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE);
								if ($source_type == 'user' || $source_type == 'all') {
									$criteria .= '<div class="progress">';
									$criteria .= '<div class="progress-bar progress-bar-info" role="progressbar" title="'.$user_rating_display.'%" aria-valuenow="'.$user_rating_display.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$user_rating_display.'%">';
   									$criteria .= '<span class="sr-only">'. __('User', 'wprs').': '.$user_rating_display.'%</span>';
									$criteria .= '<div class="bar" style="width: '.$user_rating_display.'%;"></div>';
   				 					$criteria .= '</div>';
									$criteria .= '</div>';
								}
							}
							// close span
			 		$criteria .= '</div>';
				}
				$criteria .= '</div>';
				$criteria .= '</li>';
			}
			$criteria .= '</ul>';
			return $criteria;
		}
		return;
	}
	
	
	/*
    	review criteria in single comment, example wprs_review_criteria_single($id, $comment_id);
		@since 1.0.0
		*/
	function wprs_get_criteria_single($id, $comment_id) {
		
		global $wprs_prefix;
		
		if (get_post_meta($id, $wprs_prefix.'repeatable', TRUE)) {
			$myarray = get_post_meta($id, $wprs_prefix.'repeatable', TRUE);
			$criteria = '<ul class="wprs_userrating_criteria">';
				foreach($myarray as $key => $element){
					$criteria .= '<li>';
						$rating_display = $element['rating'];
						if ($element['rating'] !='No Rating') {
							// user criteria
							if (get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE)) {	
								
								if ( get_post_meta($id, $wprs_prefix.'star_rating', TRUE) != null || get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE)) {
									if ($element['desc'] !== '') {
										$criteria .= '<span title="'.$element['desc'].'">'.$element['desc'].'</span>';
									} else {
										$criteria .= '<span title="'.$element['title'].'">'.$element['title'].'</span>';
									}
								}			
								$user_rating_display = get_post_meta($id, $wprs_prefix.'userrating_criteria_'.$element['title'], TRUE);
								$user_rating_display = get_comment_meta( $comment_id, 'item_range_'.$element['title'], TRUE);

								$criteria .= '<div class="progress">';
								$criteria .= '<div class="progress-bar progress-bar-info" role="progressbar" title="'.$user_rating_display.'%" aria-valuenow="'.$user_rating_display.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$user_rating_display.'%">';
   								$criteria .= '<span class="sr-only">'. __('User', 'wprs').': '.$user_rating_display.'%</span>';
								$criteria .= '<div class="bar" style="width: '.$user_rating_display.'%;"></div>';
							}
				}
				$criteria .= '</li>';
			}
			/*
			$userrating = get_comment_meta( $comment_id, 'wprs_userrating', true );
			// display rating stars
			$criteria .= '<li class="wprs_align_center">';
			$criteria .= '<span class="sr-only">'. __('Rated', 'wprs').' '.$userrating.' '. __('stars', 'wprs').'</span>';
			$criteria .= '<span class="rating rating-comment r-'.$userrating.'" title="'. __('Rating:', 'wprs') .' ' . $userrating . '"></span>';
			$criteria .= '</li>';
			*/
			$criteria .= '</ul>';
			return $criteria;
		}
		return;
	}
	

	/*
    	get Links
		@since 1.0.0
    	*/
	function wprs_getReviewLinks($id) {
		
		global $wprs_prefix;
		
		$options = get_option('wprs_options');
		
		// get button color
		if ($options['wprs_drp_button_color'] != '') {$rating_box_btn_color = $options['wprs_drp_button_color'];} else {$rating_box_btn_color = 'blue';}
		// get more details button value
		if ($options['wprs_more_details_btn_value'] != '') {$rating_box_btn_value = $options['wprs_more_details_btn_value'];} else {$rating_box_btn_value = __('More Details', 'wprs');}
		// get demo button color
		if ($options['wprs_drp_button_dcolor'] != '') {$rating_box_btn_dcolor = $options['wprs_drp_button_dcolor'];} else {$rating_box_btn_dcolor = 'orange';}
		// get demo button value
		if ($options['wprs_demo_btn_value'] != '') {$review_text_dbutton = $options['wprs_demo_btn_value'];} else {$review_text_dbutton = __('Demo', 'wprs');}
	
		$button = '';
		
		//check if there is a url link			
		if (get_post_meta($id, $wprs_prefix.'item_url', TRUE)) {
								
			// check button text
			if (get_post_meta($id, $wprs_prefix.'button_text', TRUE) == null) {
				$review_text_button = $rating_box_btn_value; // use default 'More Details', or global
			} else {
				$review_text_button = get_post_meta($id, $wprs_prefix.'button_text', TRUE);
			}
		
			$button .= '<ul class="wprs_links">';					
			$button .= '<li>';
			$button .= '<div class="clr"></div>';
			$button .= '<div class="" align="center">';
			
			// review link
			$button .= '<a itemprop="url" class="ar_button ar_' . $rating_box_btn_color . '" href="' . get_post_meta($id, $wprs_prefix.'item_url', TRUE) . '" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '"'.wprs_getWindowTarget().wprs_getDofollow($id).'><nobr><span class="icon-external-link"></span> '.$review_text_button.'</nobr></a>';
			
			// demo link
			if (get_post_meta($id, $wprs_prefix.'item_demo_url', TRUE) != null) {				
				$button .= ' '; // add a space between buttons
				$button .= '<a itemprop="url" class="ar_button ar_' . $rating_box_btn_dcolor . '" href="' . get_post_meta($id, $wprs_prefix.'item_demo_url', TRUE) . '" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '"'.wprs_getWindowTarget().wprs_getDofollow($id).'><nobr><span class="icon-desktop"></span> '.$review_text_dbutton.'</nobr></a>';
			}
			
			$button .= '</div>';
			$button .= '<div class="clr"></div>';
			$button .= '</li>';
			$button .= '</ul>';
		}
		
		return $button;
	}
	



	/*
    	get Review Links Mini
		@since 1.0.0
		*/
	
	function wprs_getReviewLinksMini($id) {
		
		global $wprs_prefix;
		
		$options = get_option('wprs_options');
		//if (isset($options['wprs_chk_link_window']) != true ) return '';
		
		// get button color
		if ($options['wprs_drp_button_color'] != '') {$rating_box_btn_color = $options['wprs_drp_button_color'];} else {$rating_box_btn_color = 'blue';}
		// get more details button value
		if ($options['wprs_more_details_btn_value'] != '') {$rating_box_btn_value = $options['wprs_more_details_btn_value'];} else {$rating_box_btn_value = __('More Details', 'wprs');}
		// get demo button color
		if ($options['wprs_drp_button_dcolor'] != '') {$rating_box_btn_dcolor = $options['wprs_drp_button_dcolor'];} else {$rating_box_btn_dcolor = 'orange';}
		// get demo button value
		if ($options['wprs_demo_btn_value'] != '') {$review_text_dbutton = $options['wprs_demo_btn_value'];} else {$review_text_dbutton = __('Demo', 'wprs');}
	
		$button = '';
		
		//check if there is a url link			
		if (get_post_meta($id, $wprs_prefix.'item_url', TRUE)) {
			
			// check button text
			if (get_post_meta($id, $wprs_prefix.'button_text', TRUE) == null) {
				$review_text_button = $rating_box_btn_value; // use default 'More Details', or global
			} else {
				$review_text_button = get_post_meta($id, $wprs_prefix.'button_text', TRUE);
			}
								
			$button .= '<ul class="wprs_links">';					
			$button .= '<li>';
			$button .= '<div class="clr"></div>';
			$button .= '<div class="min_btn">';
			
			// review link
			$button .= '<a itemprop="url" class="ar_button ar_' . $rating_box_btn_color . '" href="' . get_post_meta($id, $wprs_prefix.'item_url', TRUE) . '" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '"'.wprs_getWindowTarget().wprs_getDofollow($id).'><nobr><span class="icon-external-link"></span> '.$review_text_button.'</nobr></a>';
			
			// demo link
			if (get_post_meta($id, $wprs_prefix.'item_demo_url', TRUE) != null) {				
				$button .= ' '; // add a space between buttons
				$button .= '<br />'; // add space break between buttons
				$button .= '<a itemprop="url" class="ar_button ar_' . $rating_box_btn_dcolor . '" href="' . get_post_meta($id, $wprs_prefix.'item_demo_url', TRUE) . '" title="' . get_post_meta($id, $wprs_prefix.'item_name', TRUE) . '"'.wprs_getWindowTarget().wprs_getDofollow($id).'><nobr><span class="icon-desktop"></span> '.$review_text_dbutton.'</nobr></a>';
			}
			
			$button .= '</div>';
			$button .= '<div class="clr"></div>';
			$button .= '</li>';
			$button .= '</ul>';
		}
		
		return $button;
	}
	
				
	/*
    	get Review Link Target
		@since 1.0.0
    	*/
	function wprs_getWindowTarget() {
		global $post, $wprs_prefix;
		$options = get_option('wprs_options');
		if(!get_post_meta($post->ID, $wprs_prefix.'link_target', TRUE) == null) return;
		if (!isset($options['wprs_chk_link_window']) != true) return;
		return 'target="_blank"';
	}
	
			
	/*
    	get Review Link Dofollow
		@since 1.0.0
    	*/
	function wprs_getDofollow($id) {
		global $wprs_prefix;
		if (get_post_meta($id, $wprs_prefix.'link_dofollow', TRUE) == null) return 'rel="nofollow"';
		return;
	}
	

	/*
    	return 0, review, reviews, example wprs_get_user_reviews_count($count);
		@since 1.0.0
		*/
	function wprs_get_user_reviews_count ($count) {
		$icon = '<span class="fa fa-user"></span> ';
		if ($count == 0) return '('.$count.') '.$icon.__('No reviews yet!', 'wprs');
		if ($count == 1) return '('.$count.') '.$icon.__('Review', 'wprs');
  		return '('.$count.') '.$icon.'<span class="hidden-xs">' . __('Reviews', 'wprs').'</span>';
	}
	
	
	/*
    	return add review link, example wprs_get_add_your_review();
		@since 1.0.0
		*/
	function wprs_get_add_your_review() {
		$options = get_option('wprs_options');
		$my_theme = wp_get_theme();
		$classes = 'wprs_submit_review';
		
		// check user is review author, do not display respond icon (if logged in)
		if (wprs_is_user_author()) return '';
		
		if (!isset($options['wprs_chk_user_rating_popup_enable']) != '') {
			// check if Thesis theme is active
			if ( $my_theme->Name == 'Thesis') {
				$respond_url = get_permalink() . '#commentform';
			} else {
				$respond_url = get_permalink() . '#respond';
			}
		} else {
			$respond_url = '#inline_content';
			$classes .= ' inline';
		}
			
		$respond_link = ' <a class="'.$classes.'" href="'.$respond_url.'" title="'.__('Submit Your Review', 'wprs').'" rel="nofollow"><i class="fa fa-plus-circle"></i></a>';

		return apply_filters( 'wprs_add_your_review', $respond_link );
	}
	
	
	/*
    	return add review link button, example wprs_get_add_your_review_button();
		to be used with aggregate reviews
		@since 1.0.0
		*/
	function wprs_get_add_your_review_button() {
		$options = get_option('wprs_options');
		$my_theme = wp_get_theme();
		$classes = 'wprs_submit_review';
		
		// check user is review author, do not display respond icon (if logged in)
		if (wprs_is_user_author()) return '';
		
		if (!isset($options['wprs_chk_user_rating_popup_enable']) != '') {
			// check if Thesis theme is active
			if ( $my_theme->Name == 'Thesis') {
				$respond_url = get_permalink() . '#commentform';
			} else {
				$respond_url = get_permalink() . '#respond';
			}
		} else {
			$respond_url = '#inline_content';
			$classes .= ' inline';
		}
			
		$respond_link = '<div class="wprs_add_review">';
		$respond_link .= '<p>';
		$respond_link .= '<a class="'.$classes.' ar_button ar_blue" href="'.$respond_url.'" title="'.__('Add Your Review','wprs').'">';
		$respond_link .= '<i class="fa fa-plus-circle"></i>';
		$respond_link .= ' '.__('Add Review','wprs');
		$respond_link .= '</a>';
		$respond_link .= '</p>';
		$respond_link .= '</div>';

		return apply_filters( 'wprs_add_your_review_button', $respond_link );
	}
	
		
	add_action('admin_bar_menu', 'wprs_admin_bar_menu_items', 99);
	/*
    	add Google Rich Snippet Test Tool link to admin bar menu 
		@since 1.0.0
		*/
	function wprs_admin_bar_menu_items($admin_bar) {
		
		/* This print_r will show you the current contents of the admin menu bar, use it if you want to examine the $admin_bar array
		* echo "<pre>";
		* print_r($admin_bar);
		* echo "</pre>";
		*/
		
		// if it's admin page, then get out!
		if (is_admin()) return;
		// if front, home or archive, then get out!
		if (is_front_page() || is_home() || is_archive() ) return;
		// get global post
		global $post;
		// get post id
		$id = get_the_ID();
		// if it's not a review, then get out!
		if (!wprs_is_enabled($id)) return;
		// if user can't, then get out
		if ( !current_user_can( 'edit_post', $id ) ) return;
		// get post permalink
		$permalink = get_permalink( $id );
		// add menu item
		$admin_bar->add_menu( array(
			'id'	=> 'wprs-test-item',
			//'parent' => 'top-secondary',
			'title'	=> __('Test', 'wprs'),
			'href'	=> 'http://www.google.com/webmasters/tools/richsnippets?url='.$permalink,
			'meta'	=> array(
				'title'		=> __('Structured Data Testing Tool', 'wprs'),
				'class'		=> 'wprs_bar_star',
				'target'	=> __('_blank')
			),
		) );
	}
	
	
	/*
    	get custom post types
		@since 1.0.0
		*/
	function wprs_get_post_types() {
		$options = get_option('wprs_options');
		$active_post_types = array();
		$args = array('public'   => true,
				'_builtin' => false
			);
		$output = 'names'; // names or objects, note names is the default
		$operator = 'and'; // 'and' or 'or'
		$post_types = get_post_types($args,$output,$operator);
		foreach ( $post_types as $post_type ) {
			// check if custom post type is enabled
			if (isset($options['wprs_chk_post_type_'.$post_type])) {
				// add active custom post types to array
				$active_post_types[] = $post_type;
			}
		}

		// add post if it's enabled within the plugin settings
		if (isset($options['wprs_chk_post_type_post'])) {
			$active_post_types[] = 'post';
		}
		// add post if it's enabled within the plugin settings
		if (isset($options['wprs_chk_post_type_page'])) {
			$active_post_types[] = 'page';
		}
		
		return $active_post_types;
	}


	/*
    	shorten content, example wprs_short_content ($text, $limit);
		@since 1.0.0
		*/
	function wprs_short_content ($text, $limit) {
  		$text_array = explode(' ', $text, $limit - 1);
  		$short_text = implode(' ', $text_array);
  		// manipulate the string if you need to
  		return $short_text;
	}


			
	/*
    	get media, example wprs_review_media($id);
		@since 1.0.0
		*/
	function wprs_get_media($id) {
		
		global $wprs_prefix;
		
		$options = get_option('wprs_options');
		
		$media_content = '';
		$image_src = '';
		$video = '';
		$media = '';
		$title = '';
		$img = '';
		$alt = '';
		$url = '';
		
		// get stuff
		if ( get_post_meta($id, $wprs_prefix.'item_name', TRUE) ) {$title = get_post_meta($id, $wprs_prefix.'item_name', TRUE);}
		if ( get_post_meta($id, $wprs_prefix.'item_url', TRUE) ) {$url = get_post_meta($id, $wprs_prefix.'item_url', TRUE);}
		if ( get_post_meta($id, $wprs_prefix.'youtube', TRUE) ) {$video = get_post_meta($id, $wprs_prefix.'youtube', TRUE);}
		// get image alt
		// @since 1.0.0.8.8
		if (get_post_meta($id, $wprs_prefix.'image_alt', TRUE)) {
			$alt = get_post_meta($id, $wprs_prefix.'image_alt', TRUE);
		} else { // if no value, then...
			if (get_post_meta($id, $wprs_prefix.'item_name', TRUE)) {
				$alt = get_post_meta($id, $wprs_prefix.'item_name', TRUE);// set to review name
			} else {$alt = '';}
		}
		
		// featured image
		// this will override review image field
		if ( !isset($options['wprs_chk_featured_img_disable']) ) {
			if ( has_post_thumbnail($id) ) { // check if the post has a Post Thumbnail assigned to it.
				$featured_img = wp_get_attachment_image_src( get_post_thumbnail_id($id), 'single-post-thumbnail' );
				$image_src = $featured_img[0];
			}
		}
		
		// review image	
		if (get_post_meta($id, $wprs_prefix.'image', TRUE)) {
			// get image url	
			$image_src = stripslashes (get_post_meta( $id, $wprs_prefix.'image', TRUE ));
			// check is auto-resize is enabled in plugin settings
			if ( isset($options['wprs_chk_img_size_enable']) && $options['wprs_chk_img_size_enable'] != '' ) {
				$image_src = wprs_resize($image_src, 320, 120, true);
			}
		}
			
		// check if there is a url link
		if ( $url != null && $image_src !='' ) {
			$media = '<a class="media" href="' . $url . '" title="' . $title . '"' . wprs_getWindowTarget() . wprs_getDofollow($id). '>';
			$media .= '<img itemprop="image" class="photo" src="' . $image_src . '" alt="' . $alt .'" />';
			$media .= '</a>';
		} else { // no link
			if ( $image_src !='' ) {
				$media = '<img itemprop="image" class="photo" src="' . $image_src . '" alt="' . $alt .'" />';
			}
		}

		// slider shortcode
		// this will override other ways to display review image
		if (get_post_meta($id, $wprs_prefix.'slider_shortcode', TRUE)) {
			$shortcode = get_post_meta($id, $wprs_prefix.'slider_shortcode', TRUE);
			$media = '<div class="media">';
			$media .= do_shortcode( $shortcode );
			$media .= '</div>';
		}
		
		// gallery slider shortcode
		// use the default built-in slider
		if (get_post_meta($id, $wprs_prefix.'gallery_slider', TRUE)) {
			$shortcode = '[wprs_slider]';
			$media = '<div class="media">';
			$media .= do_shortcode( $shortcode );
			$media .= '</div>';
		}
		
		// Youtube video
		// this will override other ways to display review image
		if ( $video ) {
			$media = '<div class="media">';
			$media .= wp_oembed_get( $video );
			$media .= '</div>';
		}
		
		// display media
		if ( !empty($media) ) {
			// before
			//$media_content .= '<div class="col-md-12">';
			// add image 
			$media_content .= $media;
			// after
			//$media_content .= '</div>';
			// return media
			return apply_filters( 'wprs_box_media', $media_content );
		}
		// return nothing
		return;
	}
	
		
	/*
    	get media, example wprs_review_media_extend($id);
		mostly this will be used via widgets
		@since 1.0.0
    	*/
	function wprs_review_media_extend($id, $width=320, $height=120) {
		
		global $wprs_prefix;
		
		// get options
		$options = get_option('wprs_options');
		$media_content = '';
		$image_src = '';
		$video = '';
		$media = '';
		$title = '';
		$img = '';
		$alt = '';
		$url = '';
		
		// get stuff
		$url = get_permalink($id);
		if ( get_post_meta($id, $wprs_prefix.'image', TRUE) ) {$title = get_post_meta($id, $wprs_prefix.'image', TRUE);}
		if ( get_post_meta($id, $wprs_prefix.'youtube_video', TRUE) ) {$video = get_post_meta($id, $wprs_prefix.'youtube_video', TRUE);}
		// get image alt
		if (get_post_meta($id, $wprs_prefix.'image_alt', TRUE)) {
			$alt = get_post_meta($id, $wprs_prefix.'image_alt', TRUE);
		} else { // if no value, then...
			if (get_post_meta($id, $wprs_prefix.'item_name', TRUE)) {
				$alt = get_post_meta($id, $wprs_prefix.'item_name', TRUE);// set to review name
			} else {$alt = '';}
		}
		
		// featured image
		// this will override review image field
		if ( has_post_thumbnail($id) ) { // check if the post has a Post Thumbnail assigned to it.
			//$featured_img = wp_get_attachment_image_src( get_post_thumbnail_id($id), 'single-post-thumbnail' );
			$image_src = $featured_img[0];
			$image_src = wprs_resize($featured_img[0], $width, $height, true);
		}
		
		// post image	
		if (get_post_meta($id, $wprs_prefix.'image', TRUE)) {
			// get image url	
			$image_src = stripslashes (get_post_meta( $id, $wprs_prefix.'image', TRUE ));
			// check if auto-resize is enabled in plugin settings
			if ( isset($options['wprs_chk_img_size_enable']) && $options['wprs_chk_img_size_enable'] != '' ) {
				$image_src = wprs_resize($image_src, $width, $height, true);
			}
		}
		
		// get image from galley & slider
		if (get_post_meta($id, $wprs_prefix.'gallery_slider', TRUE) || get_post_meta($id, $wprs_prefix.'slider_shortcode', TRUE)) {
			$image_src = wprs_resize(wprs_first_image($id), $width, $height, true);
		}
		
		// get image from YouTube video
		if ( $video ) {
			$video_id = wprs_youtube_id_from_url($video);
			//$image_src = 'http://img.youtube.com/vi/'.$video_id.'/hqdefault.jpg';
			$image_src = 'http://img.youtube.com/vi/'.$video_id.'/mqdefault.jpg';
			//$image_src = 'http://img.youtube.com/vi/'.$video_id.'/sddefault.jpg';
			//$image_src = 'http://img.youtube.com/vi/'.$video_id.'/maxresdefault.jpg';
		}
		
		// check if there is a url link
		if ( $url != null && $image_src !='' ) {
			//$media = '<a href="' . $url . '" title="' . $title . '"' . wprs_getWindowTarget() . wprs_getDofollow($id). '>';
			$media = '<a href="' . $url . '" title="' . $title . '">';
			$media .= '<img itemprop="image" class="widget_review_screenshot_img photo" src="'.$image_src.'" alt="'.$alt.'" width="'.$width.'" height="'.$height.'" />';
			$media .= '</a>';
			
		} else { // no link
			if ( $image_src !='' ) {
				$media = '<img itemprop="image" class="widget_review_screenshot_img photo" src="' . $image_src . '" alt="' . $alt .'" width="'.$width.'" height="'.$height.'" />';
			}
		}
		
		// display media
		if ( isset($media) ) {
			$media_content .= $media;
			return $media_content;
		}
		return;
	}


	/*
    	get the first image in WP gallery, example wprs_first_image($id);
		to be used by widgets
		@since 1.0.0
    	*/

	function wprs_first_image( $id ) {
		$args = array(
			'numberposts' => 1,
			'order' => 'ASC',
			'post_mime_type' => 'image',
			'post_parent' => $id,
			'post_status' => null,
			'post_type' => 'attachment',
		);
		$img ='';
		$attachments = get_children( $args );

		if ( $attachments ) {
			foreach ( $attachments as $attachment ) {
				$image_attributes = wp_get_attachment_image_src( $attachment->ID, 'thumbnail' )  ? wp_get_attachment_image_src( $attachment->ID, 'thumbnail' ) : wp_get_attachment_image_src( $attachment->ID, 'full' );

				$img = wp_get_attachment_thumb_url( $attachment->ID, 'full');
				//$img = wp_get_attachment_thumb_url( $attachment->ID, 'wprs-thumb');
				//$img = wp_get_attachment_image_src( $attachment->ID, 'wprs-thumb', false );
				
				return $img;
			}
		}
	}


	/*
		get youtube video ID from URL, example wprs_youtube_id_from_url($url);
		@since 1.0.0
		*/
	function wprs_youtube_id_from_url($url) {
		$pattern = 
					'%^# Match any youtube URL
					(?:https?://)?  # Optional scheme. Either http or https
					(?:www\.)?      # Optional www subdomain
					(?:             # Group host alternatives
					youtu\.be/    # Either youtu.be,
					| youtube\.com  # or youtube.com
					(?:           # Group path alternatives
					/embed/     # Either /embed/
					| /v/         # or /v/
					| /watch\?v=  # or /watch\?v=
					)             # End path alternatives.
					)               # End host alternatives.
					([\w-]{10,12})  # Allow 10-12 for 11 char youtube id.
					$%x';
		$result = preg_match($pattern, $url, $matches);
		if (false !== $result) {
			return $matches[1];
		}
		return false;
	}





	/*
    	resize images, example wprs_resize($img_url, 100, 75, true);
		@since 1.0.0
		Note: not sure if I am going to use this function!
    	*/

	/**
	* Title : Aqua Resizer
	* Description : Resizes WordPress images on the fly
	* Version : 1.1.6
	* Author : Syamil MJ
	* Author URI : http://aquagraphite.com
	* License : WTFPL - http://sam.zoy.org/wtfpl/
	* Documentation : https://github.com/sy4mil/Aqua-Resizer/
	*
	* @param string $url - (required) must be uploaded using wp media uploader
	* @param int $width - (required)
	* @param int $height - (optional)
	* @param bool $crop - (optional) default to soft crop
	* @param bool $single - (optional) returns an array if false
	* @uses wp_upload_dir()
	* @uses image_resize_dimensions() | image_resize()
	* @uses wp_get_image_editor()
	*
	* @return str|array
	*/

	function wprs_resize( $url, $width, $height = null, $crop = null, $single = true ) {
		//validate inputs
		if(!$url OR !$width ) return false;

		//define upload path & dir
		$upload_info = wp_upload_dir();
		$upload_dir = $upload_info['basedir'];
		$upload_url = $upload_info['baseurl'];

		//check if $img_url is local
		if(strpos( $url, $upload_url ) === false) return false;

		//define path of image
		$rel_path = str_replace( $upload_url, '', $url);
		$img_path = $upload_dir . $rel_path;

		//check if img path exists, and is an image indeed
		if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

		//get image info
		$info = pathinfo($img_path);
		$ext = $info['extension'];
		list($orig_w,$orig_h) = getimagesize($img_path);

		//get image size after cropping
		$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
		$dst_w = $dims[4];
		$dst_h = $dims[5];

		//use this to check if cropped image already exists, so we can return that instead
		$suffix = "{$dst_w}x{$dst_h}";
		$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
		$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

		if(!$dst_h) {
			//can't resize, so return original url
			$img_url = $url;
			$dst_w = $orig_w;
			$dst_h = $orig_h;
		}
		//else check if cache exists
		elseif(file_exists($destfilename) && getimagesize($destfilename)) {
			$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
		}
		//else, we resize the image and return the new resized image url
		else {

			// Note: This pre-3.5 fallback check will edited out in subsequent version
			if(function_exists('wp_get_image_editor')) {

				$editor = wp_get_image_editor($img_path);

				if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
				return false;

				$resized_file = $editor->save();

				if(!is_wp_error($resized_file)) {
					$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
					$img_url = $upload_url . $resized_rel_path;
				} else {
					return false;
				}

			} else {

				$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
				if(!is_wp_error($resized_img_path)) {
					$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
					$img_url = $upload_url . $resized_rel_path;
				} else {
					return false;
				}

			}

		}

		//return the output
		if($single) {
			//str return
			$image = $img_url;
		} else {
			//array return
			$image = array (
				0 => $img_url,
				1 => $dst_w,
				2 => $dst_h
			);
		}

		return $image;
	}


	
	/*
		retrieves the attachment ID from the file URL
		@since 1.0.0
		Note: This function is not used!
		*/
	function wprs_get_image_id($image_url) {
		global $wpdb;
		$prefix = $wpdb->prefix;
		$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM " . $prefix . "posts" . " WHERE guid='%s';", $image_url )); 
        return $attachment[0]; 
	}
	
	function wprs_url_to_attachmentid( $image_url ) {
		if ( empty( $image_url ) )
		return null;

		global $wpdb;

		$attachment = wp_cache_get( "featured_column_thumbnail_" . md5( $image_url ), null );
		if ( false === $attachment ) {
			$attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE guid = ‘%s’;", $image_url ) );
			wp_cache_add( "featured_column_thumbnail_" . md5( $image_url ), $attachment, null );
		}

		return !empty( $attachment ) ? $attachment[0] : null;
	}	

	/*
		add image sizes
		@since 1.0.0
		Note: to be used in widgets and by add-ones
		*/
	add_action( 'init', 'wprs_add_image_sizes' );
	function wprs_add_image_sizes() {
		add_image_size( 'wprs-thumb', 320, 180, false );
	}

	add_filter('image_size_names_choose', 'wprs_show_image_sizes');
	function wprs_show_image_sizes($sizes) {
		$sizes['wprs-thumb'] = __( 'WPRS Thumb', 'wprs' );
		return $sizes;
	}


	/*
		return cons
		@since 1.0.0
		*/
	function wprs_cons($id){	
		global $wprs_prefix;
		
		$display = get_post_meta( $id, $wprs_prefix.'display_pros_cons', true ) ? true : false;
		if ($display) return;
		
		$cons = get_post_meta( $id, $wprs_prefix.'cons', true ) ? get_post_meta( $id, $wprs_prefix.'cons', true ) : '';
		$content ='';
		
		if ($cons !='') {
			$content .= '<div class="wprs_cons">';
			$content .= '<h3><i class="fa fa-thumbs-down"></i> '. __('Cons', 'wprs') .'</h3>';
			$content .= '<p>' . $cons . '</p>';
			$content .= '</div>';
		}
		
		return apply_filters( 'wprs_cons', $content );

	}
	
	
	/*
		return pros
		@since 1.0.0
		*/
	function wprs_pros($id){	
		global $wprs_prefix;
		
		$display = get_post_meta( $id, $wprs_prefix.'display_pros_cons', true ) ? true : false;
		if ($display) return;
		
		$pros = get_post_meta( $id, $wprs_prefix.'pros', true ) ? get_post_meta( $id, $wprs_prefix.'pros', true ) : '';
		$content ='';
		
		if ($pros !='') {
			$content .= '<div class="wprs_pros">';
			$content .= '<h3><i class="fa fa-thumbs-up"></i> '. __('Pros', 'wprs') .'</h3>';
			$content .= '<p>' . $pros . '</p>';
			$content .= '</div>';
		}
		
		return apply_filters( 'wprs_pros', $content );

	}
	
	
	/*
		return Google maps
		@since 1.0.0
		*/
	function wprs_get_map($id){
		global $wprs_prefix;
		$map = get_post_meta( $id, $wprs_prefix.'map', true ) ? get_post_meta( $id, $wprs_prefix.'map', true ) : '';
		$map = '<div class="wprs_map">'.$map.'</div>';
		return $map;
	}
	
	
	/*
		return restaurant cuisine categories
		@since 1.0.0
		*/
	function wprs_get_cuisine($id){
		global $wprs_prefix;
		
		$cuisine = '';
		
		$cuisine_1 = get_post_meta( $id, $wprs_prefix.'cuisine_1', true ) ? get_post_meta( $id, $wprs_prefix.'cuisine_1', true ) : '';
		$cuisine_2 = get_post_meta( $id, $wprs_prefix.'cuisine_2', true ) ? get_post_meta( $id, $wprs_prefix.'cuisine_2', true ) : '';
		$cuisine_3 = get_post_meta( $id, $wprs_prefix.'cuisine_3', true ) ? get_post_meta( $id, $wprs_prefix.'cuisine_3', true ) : '';
		
		if ($cuisine_1) { $cuisine .= '<span itemprop="servesCuisine">'.$cuisine_1.'</span>'; }
		if ($cuisine_2) { $cuisine .= ', <span itemprop="servesCuisine">'.$cuisine_2.'</span>'; }
		if ($cuisine_3) { $cuisine .= ', <span itemprop="servesCuisine">'.$cuisine_3.'</span>'; }
		
		if ($cuisine) {
			$cuisine = '<div class="wprs_cuisine"><i class="fa fa-tags"></i> ' . $cuisine . '</div>';
		}
		
		return $cuisine;
		
	}
	
	/*
		return openning hours
		@since 1.0.0
		*/
	function wprs_get_openhours($id){
		global $wprs_prefix;
		$openhours = '';
		$myarray = array();
		$myarray = get_post_meta( $id, $wprs_prefix.'openinghours', true ) ? get_post_meta( $id, $wprs_prefix.'openinghours', true ) : '';
		
		$days = array(
					'Su' => 'Sun',
					'Mo' => 'Mon',
					'Tu' => 'Tue',
					'We' => 'Wed',
					'Th' => 'Thu',
					'Fr' => 'Fri',
					'Sa' => 'Sat'
				);
		
		if (!empty($myarray)) {
			$openhours .= '<div class="wprs_opentime">';
			$openhours .= '<ul>';
			foreach($myarray as $key => $element){
				$from_day = $days[$element['from_day']];
				$to_day = $days[$element['to_day']];
				$openhours .= '<li><i class="fa fa-clock-o"></i> ';
				$openhours .= '<meta itemprop="openingHours" content="'.$element['from_day'].'-'.$element['to_day'].' '.$element['from_time'].':00-'.$element['to_time'].':00">';
				$openhours .= '<span><b>'.$from_day.' - '.$to_day.'</b></span> ';
				$openhours .= '<span>'.date("g:ia", strtotime($element['from_time'].':00')).' - '.date("g:ia", strtotime($element['to_time'].':00')).'</span>';
				$openhours .= '</li>';
			}
			$openhours .= '</ul>';
			$openhours .= '</div>';
		}
		
		return $openhours;
		
	}
	

	/*
		return take reservation
		@since 1.0.0
		*/
	function wprs_get_reservations($id){
		global $wprs_prefix;
		$reservations = get_post_meta( $id, $wprs_prefix.'reservations', true ) ? true : false;
		if ($reservations) return '<div class="wprs_reservations"><span>Take Reservations: Yes!</span></div>';
		
		return;
		
	}
	
	/*
		return take reservation
		@since 1.0.0
		*/
	function wprs_get_restaurant_menu($id){
		global $wprs_prefix;
		$menu_url = get_post_meta( $id, $wprs_prefix.'restaurant_menu', true ) ? get_post_meta( $id, $wprs_prefix.'restaurant_menu', true ) : '';
		if ($menu_url) return '<div class="wprs_restaurant_menu"><span>'.__('View','wprs').' <a itemprop="menu" href="'.$menu_url.'" rel="nofollow">menu</a></span></div>';
		
		return;
		
	}