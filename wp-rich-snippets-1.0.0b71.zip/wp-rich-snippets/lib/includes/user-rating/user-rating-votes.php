<?php
/*
	User rating stars vote functions
	
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
    */
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

	/*
    	load user rating scripts and styles
		@since 1.0.0
    	*/
	function wprs_user_rating_scripts() {
		
		if (is_admin()) return;
		
		global $post;
			
		if (!wprs_is_enabled($post->ID)) return;

		if (wprs_get_type() != 'votes') return;
			
		// register scripts
		wp_register_script(	'wprs-raty', WPRS_JS_URL.'user-rating/jquery.raty.min.js');

		// enqueue the script
		wp_enqueue_script('jquery');
		wp_enqueue_script( 'wprs-raty' );

	}
	add_action( 'wp_enqueue_scripts', 'wprs_user_rating_scripts', 5 );

		
	/**********************************************************************
    	load comment rating styles
		@since 1.0.0.0
    /**********************************************************************/
	function wprs_user_rating_styles() {
		
		if (is_admin()) return;
		
		global $post;
			
		if (!wprs_is_enabled($post->ID)) return;

		if (wprs_get_type() != 'votes') return;
		
		// register styles
		wp_register_style( 'jquery-ui-theme', WPRS_CSS_URL.'smoothness/jquery-ui-1.10.3.custom.min.css', array(), '1.0', 'all' );
		
		// enqueue the style
		wp_enqueue_style( 'jquery-ui-theme' );

	}
	//add_action( 'wp_enqueue_scripts', 'wprs_user_rating_styles' );
	
	

	/*
    	return user rating stars
		@since 1.0.0
    	*/
	function wprs_get_user_rating_stars() {
		
		global $post, $wprs_prefix;
		$count = get_post_meta( $post->ID, $wprs_prefix.'user_rating_count', true );
		$rating = get_post_meta( $post->ID, $wprs_prefix.'user_rating', true ) ? get_post_meta( $post->ID, $wprs_prefix.'user_rating', true ) : 0;
		$rating = 0;
		$id = 'wprs_user_rating_stars';
		$hint = 'wprs_user_rating_stars_hint';
		$content = '';
		
		$content .= '<div>';
		$content .= '<span id="wprs_user_rating_wait" style="float: left; margin-right: 5px;display: block;"></span>';
		$content .= '<span class="wprs_user_rating_stars">';
		$content .= '<span id="'.$id .'" data-score="'.$rating.'"></span>';		
		$content .= '</span>';
		$content .= '</div>';
		
		$content .= '<span id="'.$hint.'" class="'.$hint.'"></span>';
		$content .= '<br>';
		$content .= '<span id="wprs_user_rating_success"></span>';
		
		return $content;
	}
	
	/*
    	add raty to the footer
		@since 1.0.0
    	*/
	function wprs_user_rating_raty_scripts() {
		
		if (is_admin()) return;
		
		global $post, $wprs_prefix;
			
		if (!wprs_is_enabled($post->ID)) return;

		if (wprs_get_type() != 'votes') return;
		
		$path = plugins_url( '')  . '/wp-rich-snippets/assets/images/raty';
		$meta = wprs_get_meta();
		$slider_percentage = isset($meta[$wprs_prefix.'slider_percentage']) ? $meta[$wprs_prefix.'slider_percentage'] : 1;
		
		if( ! is_singular() ) return;
		
		$post_id = get_queried_object_id();
		
		$already_vote = wprs_user_already_voted($post_id);
		
		if ($already_vote) {
			
			?>
		<script type="text/javascript">
			
			jQuery(document).ready(function($) {
				
				$.fn.raty.defaults.path = '<?php echo $path; ?>';
				$.fn.raty.defaults.cancel = false;
				$.fn.raty.defaults.cancelHint = 'Cancel this rating!';
				$.fn.raty.defaults.half = true;
				$.fn.raty.defaults.size = 16;
				$.fn.raty.defaults.space = false;
			
				$('#wprs_user_rating_stars').raty({
					path		: '<?php echo $path; ?>/stars-blue',
					target		: '#wprs_user_rating_stars_hint',
					targetFormat: '{score} Stars!',
					targetType	: 'number',
					targetKeep	: true,
					readOnly	: true,
					score		: <?php echo $already_vote ?>,
					scoreName	: 'wprs_user_rating_stars',
				});
			});
		
        </script>
		<?php
		
		} else {
	
		?>
		<script type="text/javascript">
			
			var wprs26789_data = {
				action: 'wprs_rate_action',
				post_id: '<?php echo absint( $post_id ); ?>',
				nonce: '<?php echo wp_create_nonce( 'wprs_rate_nonce' ); ?>',
			}
			
			jQuery(document).ready(function($) {
				
				$.fn.raty.defaults.path = '<?php echo $path; ?>';
				$.fn.raty.defaults.cancel = false;
				$.fn.raty.defaults.cancelHint = 'Cancel this rating!';
				$.fn.raty.defaults.half = true;
				$.fn.raty.defaults.size = 16;
				$.fn.raty.defaults.space = false;
			
				$('#wprs_user_rating_stars').raty({
					path		: '<?php echo $path; ?>/stars-blue',
					target		: '#wprs_user_rating_stars_hint',
					targetFormat: '{score} Stars!',
					targetType	: 'number',
					targetKeep	: true,
					readOnly	: false,
					score		: function() {return $(this).attr('data-score');},
					scoreName	: 'wprs_user_rating_stars',
					
					click 		: function(score, evt) {
									
									var wprs26789_data = {
										action: 'wprs_rate_action',
										post_id: '<?php echo absint( $post_id ); ?>',
										nonce: '<?php echo wp_create_nonce( 'wprs_rate_nonce' ); ?>',
										score: score
									}
									
									$( 'span#wprs_user_rating_wait' ).html( '<span class="fa fa-refresh fa-spin"></span>' );
			
            						$.get( 
										'<?php echo site_url( 'wp-admin/admin-ajax.php' ); ?>', 
										wprs26789_data, 
										function( data ){
											if( '-1' != data ) {
												$( 'span#wprs_user_rating_success' ).html( '<span class="fa fa-check"></span> Thanks!' );
												$( 'span#wprs_user_rating_wait' ).html( '' );
												$( 'span#wprs_user_rating_count' ).html( '<span><?php echo wprs_get_user_rating_counter($post_id); ?></span>' );
											}
										}
									);
									
									// reset
									$('#wprs_user_rating_stars').raty('set', {
										readOnly	: true,
										score		: score,
									});
									
        						}
				});
				
			});
		
        </script>
		<?php
		}
	}
	add_action('wp_footer','wprs_user_rating_raty_scripts');


///////////////////////////
//////////////////////////

add_action( 'wp_ajax_nopriv_wprs_rate_action', 'wprs_rate_ajax_cb' );
add_action( 'wp_ajax_wprs_rate_action', 'wprs_rate_ajax_cb' );
function wprs_rate_ajax_cb() {
	
	global $wprs_prefix;
	
	// Verify the nonce to make sure the request came from an actual page...
	if( !isset( $_REQUEST['nonce'] ) || ! wp_verify_nonce( $_REQUEST['nonce'], 'wprs_rate_nonce' ) ) die( '-1' );
	
	$post_id = isset( $_REQUEST['post_id'] ) ? absint( $_REQUEST['post_id'] ) : 0;
	$rating = isset( $_REQUEST['score'] ) ? $_REQUEST['score'] : 0;
	
	if( ! $post_id ) die( '-1' );
	
	// check & update ip
	if (!wprs_user_vote_update_ip ($post_id, $rating)) die();
	
	$rating_all = get_post_meta( $post_id, $wprs_prefix.'user_rating_all', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating_all', true ) : 0;
	
	$counter = get_post_meta( $post_id, $wprs_prefix.'user_rating_count', true );
	$counter = absint( $counter );
	
	if( $counter )
	{
		$counter++;
	}
	else
	{
		$counter = 1;
	}
	
	$rating_new = $rating_all + $rating;
	$rating = round($rating_new / $counter, 1);
	
	update_post_meta( $post_id, $wprs_prefix.'user_rating_count', $counter );
	update_post_meta( $post_id, $wprs_prefix.'user_rating_all', $rating_new );
	update_post_meta( $post_id, $wprs_prefix.'user_rating', $rating );
		
	die();
}

	
	
	function wprs_user_already_voted($post_id) {
		
		global $wprs_prefix;
		
		// check ip
		$ip = get_IP();
		$ips = array();
		$ips = get_post_meta( $post_id, $wprs_prefix.'user_rating_ips', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating_ips', true ) : array();
		
		if (empty($ips)) return false;
		
		//if (in_array($ip, $ips)) {
		if (array_key_exists($ip, $ips)) {
			$rating = $ips[$ip];
			return $rating;
		}
		return false;
		
	}
	
	function wprs_user_vote_update_ip ($post_id, $rating) {
		
		global $wprs_prefix;
		
		// check ip
		$ip = get_IP();
		$ips = array();
		$ips = get_post_meta( $post_id, $wprs_prefix.'user_rating_ips', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating_ips', true ) : array();
		
		if ( empty($ips) || !in_array($ip, $ips) ) {
			$ips[$ip] = $rating;
			update_post_meta( $post_id, $wprs_prefix.'user_rating_ips', $ips );
			return true;
		}
		return false;
	}

	
	function wprs_get_user_rating_counter($post_id) {
		global $wprs_prefix;
		$counter = get_post_meta( $post_id, $wprs_prefix.'user_rating_count', true ) ? get_post_meta( $post_id, $wprs_prefix.'user_rating_count', true ) : 0;
		return intval($counter) + 1;
	}
	
