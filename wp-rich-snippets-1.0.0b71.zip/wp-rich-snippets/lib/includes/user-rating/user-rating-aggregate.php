<?php
/*
	User rating aggregate functions
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



	/*
    	get nav tabs, example wprs_get_nav_tabs();
		to be used on aggregate templates
		@since 1.0.0
		*/
	function wprs_get_nav_tabs() {
		$content = '<ul id="wprs-nav-tabs" class="nav nav-tabs">';
			$content .= '<li><a href="#item_square" data-toggle="tab"><span class="fa fa-info-circle"></span> ' . __('Review', 'wprs') . '</a></li>';
			$content .= '<li><a href="#user_reviews" data-toggle="tab"><span class="fa fa-star-half-o"></span> ' . __('User Reviews', 'wprs') . '</a></li>';
		$content .= '</ul>';
		return $content;
	}
	
	
	add_action('wp_enqueue_scripts', 'wprs_nav_tabs_scripts');
	/*
    	load nav tabs scripts
		@since 1.0.0
		*/
	function wprs_nav_tabs_scripts() {
		
		if (is_admin()) return;
		
		global $post;
			
		if (!wprs_is_enabled($post->ID)) return;

		if (wprs_get_type() != 'aggregate') return;
		
    	wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'wprs-bootstrap', WPRS_JS_URL.'bootstrap.min.js', true );
	}
	
	
	add_action('wp_footer','wprs_nav_tabs_footer_scripts');
	/*
    	load nav tabs footer scripts
		@since 1.0.0
		*/
	function wprs_nav_tabs_footer_scripts() {
		
		if (is_admin()) return;
		
		global $post;
			
		if (!wprs_is_enabled($post->ID)) return;

		if (wprs_get_type() != 'aggregate') return;
		
		// get filtered reviews to set active tab
		$active = intval(get_query_var( 'filter' )) != 0 ? 'last' : 'first';
		
		?>
		<script type="text/javascript">
			jQuery(function ($) {
				$('#wprs-nav-tabs a:<?php echo $active ?>').tab('show')
			});
		</script>
		<?php
	}
	

	/*
		get user reviews
		to be used on aggregate templates
		@since 1.0.0
		*/
	function wprs_get_user_reviews(){
		
		$post_id = get_the_ID();
		
		// get filtered reviews number
		$number = intval(get_query_var( 'filter' )) != 0 ? intval(get_query_var( 'filter' )) : '';
		
		$content = '';

		$args = array(
			'post_id'		=> get_the_ID(),
			'type'			=> 'comment',
			'status'		=> 'approve',
			'number'		=> '',				// number of comments, leave blank to return all
			'meta_key'		=> 'wprs_userrating',	//(string) - Custom field key.
			'meta_value'	=> $number,
			//'orderby'		=> '',
			'order'			=> 'DESC',
			//'post_id'		=> 1,			// use post_id, not post_ID
		);
		
		$comments = get_comments($args);
		
		$content .= apply_filters( 'wprs_user_reviews_top', '' );
		$content .='<div id="wprs_square" class="wprs_user_reviews_wrap">';
		$content .= wprs_get_user_aggregate_reviews_details();
		$content .= apply_filters( 'wprs_user_reviews_before', '' );
		
		// if there is no comment, return message!
		if (empty($comments)) {
			
			if (!empty($number)) {
				$content .= '<p><center>';
				$content .= '<span class="sr-only">' . __('No one has rated this', 'wprs') . ' ('.$number.') ' . __('stars', 'wprs').'</span>';
				$content .= '<span class="fa fa-info-circle"></span> ' . __('No one has rated this', 'wprs') . ' ('.$number.') ' . __('stars', 'wprs');
				$content .= '</center></p>';
			} else {
				$content .= '<p><center>';
				$content .= '<span class="sr-only">' . __('No one has rated this yet, be the first!', 'wprs') . '</span>';
				$content .= '<span class="fa fa-info-circle"></span> ' . __('No one has rated this yet, be the first!', 'wprs');
				$content .= '</center></p>';
				$content .= '<br />';
				$content .= wprs_get_add_your_review_button();
				
			}
			
			$content .= '<hr />';
			$content .= '</div>';
		
			$content .= apply_filters( 'wprs_user_reviews_after', '' );
			
			return apply_filters( 'wprs_user_reviews', $content );	
		
		}
		
		// display comments
		foreach($comments as $comment) :
			
			$content .= '<div class="wprs_user_reviews" itemprop="review" itemscope itemtype="http://schema.org/Review">';
				
				$comment_id = $comment->comment_ID;
				
				// get gravatar
				$gravatar_hash = md5( strtolower( trim( $comment->comment_author_email ) ) );
				$gravatar_img = '<img class="avatar avatar-50 photo" src="http://www.gravatar.com/avatar/'.$gravatar_hash.'?d=mm&r=g" alt="'.$comment->comment_author.'" width="50" height="50" />';
				$content .= '<div class="col-sm-2">' . $gravatar_img . '</div>';
				//$content .= '<div class="col-sm-2">' . get_avatar( $comment, 50 ) . '</div>';
	
				$content .= '<div class="col-sm-10">';
		
					$content .= '<span itemprop="author">' . $comment->comment_author . '</span>';
					$content .= '<meta itemprop="datePublished" content="'.$comment->comment_date.'">';
					$content .= ' <span class="date">'.__('on', 'wprs').' '.$comment->comment_date.'</span>';
		
					$headline = get_comment_meta( $comment->comment_ID , 'wprs_headline', true );
					$content .= '<h4><span itemprop="name">'.$headline.'</span></h4>';
	
					$content .= '<p><span itemprop="description">' . $comment->comment_content . '</span></p>';
					
					// get criteria
					if ( !isset($options['wprs_chk_user_creteria_to_author_display']) !='' ) {
						$content .= wprs_get_criteria_single($post_id, $comment->comment_ID);
					}
					
					// get star rating
					$userrating = get_comment_meta( $comment->comment_ID , 'wprs_userrating', true );
		
					$content .='<div class="wprs_user_rating" itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">';
						$content .= do_action( 'wprs_user_review_inside_before');
						$content .= '<div class="clr"></div>';
      					$content .= '<span class="sr-only">'. __('Rating', 'wprs') .': ' .$userrating.'</span>';
						$content .= '<span class="rating rating-user r-'.$userrating.'" title="'. __('Rating', 'wprs') .': ' . $userrating . '"></span>';
						$content .= '<meta itemprop="worstRating" content = "1">';
						$content .= '<span itemprop="ratingValue">'.$userrating.'</span> /';
						$content .= '<span itemprop="bestRating">5</span> stars';
						$content .= '<div class="clr"></div>';
						$content .= do_action( 'wprs_user_review_inside_after');
						// add-on integration
						if (function_exists('wprs_uri_display_aggregate_image')) $content .= wprs_uri_display_aggregate_image($comment_id);
					$content .='</div>';
	
				$content .= '</div>';
				$content .= '<div class="clr"></div>';
				// after single review hook
				$content .= apply_filters( 'wprs_user_review_after', '');
				$content .= '<br /><hr />';
			$content .= '</div>';
			$content .= '<div class="clr"></div>';
		endforeach;
		
		// get add your review button
		$content .= wprs_get_add_your_review_button();
		
		$content .= '</div>';
		$content .= apply_filters( 'wprs_user_reviews_after', '' );
		
		return apply_filters( 'wprs_user_reviews', $content );
	}


	
	/*
		get user reviews, example: wprs_get_user_aggregate_reviews_details()
		to be used on aggregate templates
		@since 1.0.0
		*/	
	function wprs_get_user_aggregate_reviews_details() {
		
		global $post, $wprs_prefix;
		
		$meta = wprs_get_meta();
		
		if (! isset($meta[$wprs_prefix.'userrating_average'])) {
			// if 0, return 0 percentage!
			$percentage = '<p>'.wprs_get_rating_percentage(0, 'user').'</p>';
		} else {
			$percentage = wprs_get_rating_percentage($meta[$wprs_prefix.'userrating_average'], 'user') !='' ? '<p>'.wprs_get_rating_percentage($meta[$wprs_prefix.'userrating_average'], 'user').'</p>' : '';
		}
		
		$num_reviews = get_comments_number(); // get_comments_number returns only a numeric value
		
		$write_review = '';
		
		if ( comments_open() ) {
			
			if ( $num_reviews == 0 ) {
				$reviews = __('No reviews yet!', 'wprs');
			} elseif ( $num_reviews > 1 ) {
				$reviews = $num_reviews . __(' Reviews', 'wprs');
			} else {
				$reviews = __('1 Review', 'wprs');
			}
			$write_review = apply_filters( 'wprs_box_aggregate_before', '' );
			$write_review .= '<div class="col-xs-6"><p>' . wprs_get_userrating_stars($post->ID) . wprs_get_add_your_review() . '</p></div>';
			$write_review .= '<div class="col-xs-6 text_right"><p class="text_right">' . $percentage . '</p></div>';
			if (wprs_get_userrating_array($post->ID)) {
				$write_review .= '<div class="clr"><br /></div>';
				$write_review .= '<div class="col-sm-6 wprs_progress_array">'.wprs_get_userrating_array($post->ID).'</div>';
			}
			$write_review .= '<div class="col-sm-6">'.wprs_get_criteria($post->ID, 'user').'</div>';
		} else {
			$write_review = apply_filters( 'wprs_box_aggregate_before', '' );
			$write_review .= '<p>'.__('User Reviews are disabled for this review!', 'wprs').'</p>';
		}
		
		
		$write_review .= '<div class="col-md-12"><hr /><br /></div>';
		
		$write_review .= '<div class="clr"></div>';
		
		$write_review .= apply_filters( 'wprs_box_reviews_before', '' );

		return apply_filters( 'wprs_user_reviews_details', $write_review );
	}
	
		
	/*
    	update user rating array
		@since 1.0.0
    	*/
	function wprs_update_post_userrating_array($postid, $userrating) {
		
		global $wprs_prefix;
		
		if (get_post_meta($postid, $wprs_prefix.'userrating_array', true)) {
			$ratings = get_post_meta($postid, $wprs_prefix.'userrating_array', true);
		} else {
			$rating = array();
			$ratings = array(
						5	=>	0,
						4	=>	0,
						3	=>	0,
						2	=>	0,
						1	=>	0
					);
		}
	
		$ratings[$userrating] = $ratings[$userrating] + 1;
		
		update_post_meta($postid, $wprs_prefix.'userrating_array', $ratings);
		
		// debug
		// echo '<pre>';
		// var_dump($ratings);
		// echo '</pre>';
		
	}


	/*
    	display user rating array
		@since 1.0.0
    	*/
	function wprs_get_userrating_array($postid) {
		
		global $wprs_prefix;
		
		if (get_post_meta($postid, $wprs_prefix.'userrating_array', true)) {
			$ratings = get_post_meta($postid, $wprs_prefix.'userrating_array', true);
		} else {
			$ratings = '';
		}
		
		if (!$ratings) return;
		
		$count = get_post_meta($postid, $wprs_prefix.'userrating_count', true);
		
		$permalink = get_permalink( $postid );
		
		$content = '';
		
		if ($count == 0) return;
		
		foreach(  $ratings as $k => $v ) {
			$p = ($v / $count) * 100;
			$p = round($p * 2) / 2 ;
			
			// maybe display rating?
			// $p =  round($rating * 2) / 2 ;
			// $content .= '<a href="#"><span>' .$k . ' stars</span> ' . '<span class="rating rating-user r-'.$k.'" title="Rating: '.$k.'"></span> <span>' . $v . '</span></a><br />';
			
			
			$content .= '<div class="row">';
			$content .= '<a href="' . add_query_arg( 'filter', $k, $permalink ).'">';
			
			$content .= '<div class="col-xs-4">';
			$content .= '<span>' . $k . ' ' . __( 'stars', 'wprs' ) . '</span>';
			$content .= '</div>';
			
			$content .= '<div class="col-xs-6">';
			$content .= '<div class="progress">';
			$content .= '<div class="progress-bar progress-bar-info" role="progressbar" title="'.$p.'%" aria-valuenow="'.$p.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$p.'%">';
			$content .= '<span class="sr-only">User: '.$p.'%</span>';
			$content .= '<div class="bar" style="width: '.$p.'%;"></div>';
			$content .= '</div>';
			$content .= '</div>';
			$content .= '</div>';
			
			$content .= '<div class="col-xs-2">';
			$content .= '<span class="wprs_ml_5">' . $v . '</span>';
			$content .= '</div>';
			
			$content .= '</a>';
			$content .= '</div>';
			
			
		}
		
		
		return $content;
	}

	
	add_filter('query_vars', 'wprs_userrating_add_query_vars');
	/*
    	hook wprs_userrating_add_query_vars function into query_vars
		@since 1.0.0
    	*/
	function wprs_userrating_add_query_vars($aVars) {
		$aVars[] = "filter"; // represents the name of the product category as shown in the URL
		return $aVars;
	}
 
	
	add_filter('comment_form_defaults', 'wprs_userrating_customize_comment_form_text_area', 99);	
	/*
    	hook wprs_userrating_add_query_vars function into query_vars
		@since 1.0.0
    	*/
	function wprs_userrating_customize_comment_form_text_area($arg) {
		global $post;
		if (!wprs_is_enabled($post->ID)) return $arg;
		if (wprs_get_type() != 'aggregate') return $arg;
		
		$arg['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . __( 'Your Review', 'wprs' ) . '</label><textarea id="comment" name="comment" placeholder="" cols="45" rows="4" aria-required="true"></textarea></p>';
		return $arg;
	}
 
