<!-- Comments hidden by Hide Comments Plugin -->
<?php 

$args = array(
  'id_form'           => 'commentform',
  'id_submit'         => 'submit',
  'title_reply'       => __( 'Write a Review', 'wprs' ),
  'title_reply_to'    => __( 'Leave a Reply to %s', 'wprs' ),
  'cancel_reply_link' => __( 'Cancel Reply', 'wprs' ),
  'label_submit'      => __( 'Submit Review', 'wprs' ),
);

comment_form($args);

