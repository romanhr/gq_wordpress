<?php
/*
	Schema main filter
	
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
    */
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
	
	
	/*
		Box template
		@since 1.0.0
		*/
	function wprs_template() {
	
		global $post, $wprs_prefix;
		$options = get_option('wprs_options');
		$meta = wprs_get_meta();
	
		$box_settings = array();
	
		// schema and review types
		$snippets_type = isset($meta[$wprs_prefix.'snippets_types']) ? $meta[$wprs_prefix.'snippets_types'] : '';
		$review_type = isset($meta[$wprs_prefix.'review_type']) ? $meta[$wprs_prefix.'review_type'] : 'rating';
		
		// tabs
		$nav_tabs = wprs_get_nav_tabs();
		// user reviews	
		$user_reviews = wprs_get_user_reviews();
		
		// get item name & thing
		$item_name = isset($meta[$wprs_prefix.'item_name']) ? $meta[$wprs_prefix.'item_name'] : '';
		$itemprop_name = wprs_get_itemprop_name($post->ID);
		$thing = wprs_get_Thing($post->ID);
	
		// ratings
		$review_rating = isset($meta[$wprs_prefix.'star_rating']) ? $meta[$wprs_prefix.'star_rating'] : '';
		$slider_percentage = isset($meta[$wprs_prefix.'slider_percentage']) ? $meta[$wprs_prefix.'slider_percentage'] : '';
		//$slider_value = isset($meta[$wprs_prefix.'slider_percentage']) ? $meta[$wprs_prefix.'slider_percentage'] : '';
		$user_rating = isset($meta[$wprs_prefix.'user_rating']) ? $meta[$wprs_prefix.'user_rating'] : '';
		$userrating_average = isset($meta[$wprs_prefix.'userrating_average']) ? $meta[$wprs_prefix.'userrating_average'] : '';
		$userrating_count = isset($meta[$wprs_prefix.'userrating_count']) ? $meta[$wprs_prefix.'userrating_count'] : 0;
		$userrating_review_count = wprs_get_user_reviews_count($userrating_count). wprs_get_add_your_review();
		
		$editor_star_rating = wprs_get_star_rating($review_rating);
		$user_star_rating = wprs_get_user_star_rating($post->ID);
		$user_star_aggregate = wprs_get_user_star_aggregate($post->ID);
		$user_rating_stars = wprs_get_user_rating_stars($user_rating);
		
		// $progressbar
		$progressbar_editor = wprs_get_progressbar($slider_percentage, 'editor');
		//$progressbar_user = wprs_get_progressbar($settings['slider_percentage'], 'editor');
		
		// score
		$score_editor = wprs_get_score($review_rating, 'editor');
		$score_user = wprs_get_score($user_rating, 'user');
		
		// criteria
		$criteria_editor = wprs_get_criteria($post->ID, 'editor');
		$criteria_user = wprs_get_criteria($post->ID, 'user');
		
		// percentage
		$percentage_editor = wprs_get_rating_percentage($review_rating, 'editor');
		$percentage_editor_slider = wprs_get_rating_percentage($slider_percentage, 'editor', true);
		$percentage_user = wprs_get_rating_percentage($user_rating, 'user');
		$percentage_user_average = wprs_get_rating_percentage($userrating_average, 'user');
		
		// price
		$currency = isset($options['wprs_currency']) ? $options['wprs_currency'] : 'USD';
		$currency_sympol = wprs_get_currency_symbol($currency);
		$price = wprs_get_price($post->ID, $currency_sympol);
		
		// media
		$media = wprs_get_media($post->ID);
		
		// address & maps
		$phone = wprs_get_phone($post->ID);
		$address = wprs_get_address($post->ID);
		$map = wprs_get_map($post->ID);
		
		// author
		$author = wprs_get_author_name_person($post->ID, get_the_author());
		
		// description
		$description = wprs_get_description($post->ID);
		
		// dates
		$date_published = wprs_get_dtreviewed();
		$date_modified = wprs_get_dtmodified();
		
		// links
		$links = wprs_getReviewLinks($post->ID);
		$links_mini = wprs_getReviewLinksMini($post->ID);
		
		// Cons & Pros
		$cons = wprs_cons($post->ID);
		$pros = wprs_pros($post->ID);
		
		// restaurant details
		$cuisine = wprs_get_cuisine($post->ID);
		$openhours = wprs_get_openhours($post->ID);
		$reservations = wprs_get_reservations($post->ID);
		$restaurant_menu = wprs_get_restaurant_menu($post->ID);
		
		// set hide/show class
		$reviewed_by_class = isset($options['wprs_chk_reviewed_by_hide']) ? ' wprs_magic' : '';
		$review_date_class = isset($options['wprs_chk_rating_date_hide']) ? ' wprs_magic' : '';
		$review_dmodified_class = isset($options['wprs_chk_rating_modified_date_hide']) ? ' wprs_magic' : '';
	
		// set rating box width
		if (isset($options['wprs_box_width']) != '') {$rating_box_width = $options['wprs_box_width'];} else {$rating_box_width = '300';}
				
		// set image alignment
		if (isset($options['wprs_img_alignment']) != '') {$rating_img_alignment = $options['wprs_img_alignment'];} else {$rating_img_alignment = 'left';}
				
	
		// all done!
		// now...
		// build our array of settings to be used in templates
		$wprs_template = array(
						'snippets_type'				=> $snippets_type,
						'review_type'				=> $review_type,
						'nav_tabs'					=> $nav_tabs,
						'user_reviews'				=> $user_reviews,
						'item_name'					=> $item_name,
						'itemprop_name'				=> $itemprop_name,
						'thing'						=> $thing,
						'review_rating'				=> $review_rating,
						'editor_star_rating'		=> $editor_star_rating,
						'slider_percentage'			=> $slider_percentage,
						'user_rating'				=> $user_rating,
						'userrating_average'		=> $userrating_average,
						'userrating_count'			=> $userrating_count,
						'userrating_review_count'	=> $userrating_review_count,
						'user_star_rating'			=> $user_star_rating,
						'user_star_aggregate'		=> $user_star_aggregate,
						'user_rating_stars'			=> $user_rating_stars,
						'progressbar_editor'		=> $progressbar_editor,
						//'progressbar_user'			=> $progressbar_user,
						'score_editor'				=> $score_editor,
						'percentage_editor_slider'	=> $percentage_editor_slider,
						'score_user'				=> $score_user,
						'percentage_editor'			=> $percentage_editor,
						'percentage_user'			=> $percentage_user,
						'percentage_user_average'	=> $percentage_user_average,
						'criteria_editor'			=> $criteria_editor,
						'criteria_user'				=> $criteria_user,
						'media'						=> $media,
						'phone'						=> $phone,
						'address'					=> $address,
						'map'						=> $map,
						'currency'					=> $currency,
						'currency_sympol' 			=> $currency_sympol,
						'price' 					=> $price,
						'author'					=> $author,
						'description'				=> $description,
						'date_published' 			=> $date_published,
						'date_modified' 			=> $date_modified,
						'reviewed_by_class'			=> $reviewed_by_class,
						'review_date_class'			=> $review_date_class,
						'review_dmodified_class'	=> $review_dmodified_class,
						'links'						=> $links,
						'links_mini'				=> $links_mini,
						'cons'						=> $cons,
						'pros'						=> $pros,
						'cuisine'					=> $cuisine,
						'openhours'					=> $openhours,
						'reservations'				=> $reservations,
						'restaurant_menu'			=> $restaurant_menu
						
					);
						
		return apply_filters( 'wprs_template', $wprs_template );
	
	}
	
	
	/*
		Schema
		@since 1.0.0
		*/
	function wprs_schema($content) {
		
		global $post, $wprs_prefix;
		$options = get_option('wprs_options');
		$custom = get_post_custom($post->ID);
    	
		// define $box
		$box = '';
		
		// runs on posts and pages
		// @since 1.0.0
		if (is_single($post->ID) || is_page($post->ID)) {
		
			// get meta data
			$meta = wprs_get_meta();
			//echo $meta['wprs_post_star_rating'];
			
			// get box settings
			$template = wprs_template();
			
			// schema is enabled on this entry
			// let's start...
			///////////////////////////////////
			$schema = 'http://schema.org/';
		
			switch ($template['snippets_type']) {
			
				// case type Review
				case 'Review':
					$type = 'Review';
					switch ($template['review_type']) {
						
						case 'rating':

							$box = wprs_template_review_rating();	
							break;
							
						case 'percentage':

							$box = wprs_template_review_percentage();
							break;

					}
					break;
				
				// case type Product
				case 'Product':
					
					$type = 'Product';
					switch ($template['review_type']) {
						
						case 'rating':

							$box = wprs_template_product_rating();
							break;
							
						case 'percentage':
							
							$box = wprs_template_product_percentage();
							break;
						
						case 'votes':
						
							$box = wprs_template_product_votes();	
							break;
						
						case 'aggregate':
							
							$box = wprs_template_product_aggregate();
							break;
								
					}
					break;
					
				// case type LocalBusiness
				case 'Organization':
					
					$type = 'Organization';
					switch ($template['review_type']) {
								
						case 'votes':
						
							$box = wprs_template_organization_votes();	
							break;
						
						case 'aggregate':
							
							$box = wprs_template_organization_aggregate();
							break;
								
					}
					break; 
				
				// case type Restaurant
				case 'Restaurant':
					
					$type = 'Restaurant';
					switch ($template['review_type']) {
						
						case 'votes':
						
							$box = wprs_template_restaurant_votes();	
							break;
						
						case 'aggregate':
							
							$box = wprs_template_restaurant_aggregate();
							break;
								
					}
					break;
					
				// case type Book
				case 'Book':
					
					$type = 'Book';
					break;
				
				// case type Movie
				case 'Movie':
					
					$type = 'Movie';
					break;
				
				// case type Person
				case 'Person':
					
					$type = 'Person';
					break;
					
			}
		
			// define
			$wprs_before = '';
			$wprs_after = '';			
			$reviewBody_before = '';
			$reviewBody_after = '';
			
			// prepare main divs & containers
			switch ($type) {
				
				case 'Review':
					
					$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $type . '">';
					$reviewBody_before = '<div itemprop="reviewBody">';
					$reviewBody_after = '</div>';
					$wprs_after = '</div>';
					break;
					
				case 'Product':
					
					$product_name = '';
					$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $type . '">';
					$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
					$wprs_before .= '<div itemprop="review" itemscope itemtype="http://schema.org/Review">';
					$reviewBody_before = '';
					$reviewBody_after = '';
					$wprs_after = '</div></div>';
					
					if ($template['review_type'] == 'votes' || $template['review_type'] == 'aggregate') {
						$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $type . '">';
						$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
						$wprs_after = '</div>';
						
					}
					break;
				
				case 'Organization':
					
					if (isset($meta[$wprs_prefix.'organization_type'])) {
						$organization_type = $meta[$wprs_prefix.'organization_type'] == 'General' ? 'Organization' : $meta[$wprs_prefix.'organization_type'];
					} else {
						$organization_type = 'Organization';
					}
					
					$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $organization_type . '">';
					$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
					$wprs_before .= '<div itemprop="review" itemscope itemtype="http://schema.org/Review">';
					$reviewBody_before = '';
					$reviewBody_after = '';
					$wprs_after = '</div></div>';
					
					if ($template['review_type'] == 'votes' || $template['review_type'] == 'aggregate') {
						$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $organization_type . '">';
						$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
						$wprs_after = '</div>';
						
					}
					break;
				
				case 'Restaurant':
					
					$product_name = '';
					$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $type . '">';
					$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
					$wprs_before .= '<div itemprop="review" itemscope itemtype="http://schema.org/Review">';
					$reviewBody_before = '';
					$reviewBody_after = '';
					$wprs_after = '</div></div>';
					
					if ($template['review_type'] == 'votes' || $template['review_type'] == 'aggregate') {
						$wprs_before = '<div itemscope="itemscope" itemtype="' . $schema . $type . '">';
						$wprs_before .= '<meta content="'.$template['item_name'].'" itemprop="name">';
						$wprs_after = '</div>';
						
					}
					break;
				
			}
			
			// add filters
			$wprs_before = apply_filters( 'wprs_box_before', '' ) . $wprs_before;
			$reviewBody_before =  apply_filters( 'wprs_box_after', '' ) . $reviewBody_before;
			$wprs_after = $wprs_after . apply_filters( 'wprs_content_after', '' );

			// final content output
			// decide where to display the Box
			if (isset($options['wprs_chk_display_box_below_content']) != '') {
				$content = $wprs_before . $reviewBody_before . $content . $reviewBody_after . $box .  $wprs_after;
			} else {
				$content = $wprs_before . $box . $reviewBody_before . $content . $reviewBody_after . $wprs_after;
			}
			
		}
	
		// returns the content.
    	return $content;
	}
	
	
	/*
		filter content
		*/
	function wprs_schema_content($content) {
		
		global $post;
		
		// make sure the filter do not run on the main query or main loop
		// this will eliminate filtering sidebar content and widgets
		// @since 1.0.0
		if (!in_the_loop () || !is_main_query ()) return $content;
		
		// if Rich Snippets is not enable, return
		if (!wprs_is_enabled($post->ID)) return $content;
		
		// apply schema to $content
		$content = wprs_schema($content);
		
		// return the awesome content ;)
		return $content;
		
	}
	add_filter ('the_content','wprs_schema_content');
	
