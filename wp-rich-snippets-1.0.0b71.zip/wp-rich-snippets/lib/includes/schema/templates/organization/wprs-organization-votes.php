<?php
/*
	WP Rich Snippets - LocalBusiness votes template
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



function wprs_template_organization_votes() {
	
	global $post;
    	
	// define $box
	$box = '';
	
	// get box settings
	$template = wprs_template();
	
	$box .= '<div class="wprs_container container-fluid">';
	$box .= '<div class="row">';
		
		$box .= '<div id="wprs_square">';
			
			$box .= $template['media'];
			
			$box .= '<div class="row">';
				$box .= '<div class="col-xs-6 col-sm-6 col-md-6">';
					$box .= '<ul>';
						$box .= '<li><h4><span>'. __('Readers Rating', 'wprs') .'</span></h4></li>';
						$box .= '<li>'.$template['user_star_rating'].'</li>';
						$box .= '<li>'.$template['score_user'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				
				$box .= '<div class="col-xs-6 col-sm-6 col-md-6">';
					$box .= '<ul class="al-right">';
						$box .= '<li><h4><span>'. __('Your Rating', 'wprs') .'</span></h4></li>';
						$box .= '<li>'.$template['user_rating_stars'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
			$box .= '</div>';
	
			$box .= '<hr />';

			$box .= '<div class="row">';
				$box .= '<div class="col-md-12">';
					$box .= $template['description'];
					$box .= $template['address'];
					$box .= $template['map'];
					$box .= $template['links'];
				$box .= '</div>';
			$box .= '</div>';
		
		$box .= '</div>';
			
	$box .= '</div>';
	$box .= '</div>';
	
	return apply_filters('wprs_template_product_votes', $box);
	
}
