<?php
/*
	WP Rich Snippets - review rating template
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function wprs_template_review_rating() {
	
	global $post;
    	
	// define $box
	$box = '';
	
	// get box settings
	$template = wprs_template();
	
	// debug
	//echo '<pre>';
	//ob_start();
	//call_user_func_array('var_dump', $template);
    //echo htmlentities(ob_get_clean());
	//var_dump($template);
	//echo '</pre>';
	
	$box .= '<div class="wprs_container container-fluid">';
	$box .= '<div class="row">';
		
		$box .= '<div id="wprs_square">';
			
			$box .= $template['media'];
			
			$box .= '<div class="row">';
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
					$box .= '<ul>';
						$box .= '<li><h4><span>'. __('Editor Rating', 'wprs') .'</span></h4></li>';
						$box .= '<li>'.$template['editor_star_rating'].'</li>';
						$box .= '<li>'.$template['score_editor'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">'.$template['price'].'</div>';
				
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
					$box .= '<ul class="al-right">';
						if ($template['percentage_editor'] !='') {$box .= '<li>'.$template['percentage_editor'].'</li>';}
					$box .= '</ul>';
				$box .= '</div>';
			$box .= '</div>';

			$box .= '<hr />';
			
			$box .= '<div class="row">';
				$box .= '<div class="col-md-6 wprs_mb_10">';
					$box .= '<ul>';
						$box .= '<li>'.$template['thing'].'</li>';
						$box .= '<li class="'.$template['reviewed_by_class'].'">'.$template['author'].'</li>';		
						$box .= '<li class="'.$template['review_date_class'].'">'.$template['date_published'].'</li>';
						$box .= '<li class="'.$template['review_dmodified_class'].'">'.$template['date_modified'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				$box .= '<div class="col-md-6">'.$template['criteria_editor'].'</div>';
			$box .= '</div>';

			$box .= '<hr />';

			$box .= '<div class="row">';
				$box .= '<div class="col-md-12">';
					$box .= $template['description'];
					$box .= $template['links'];		
				$box .= '</div>';
			$box .= '</div>';
		
		$box .= '</div>';
			
	$box .= '</div>';
	$box .= '</div>';
	
	
	return apply_filters('wprs_template_review_rating', $box);

}
