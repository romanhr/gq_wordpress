<?php
/*
	WP Rich Snippets - Restaurant votes template
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



function wprs_template_restaurant_votes() {
	
	global $post;
    	
	// define $box
	$box = '';
	
	// get box settings
	$template = wprs_template();
	
	$box .= '<div class="wprs_container container-fluid">';
	$box .= '<div class="row">';
		
		$box .= '<div id="wprs_square">';
			
			$box .= $template['media'];
			
			$box .= '<div class="row">';
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
					$box .= '<ul>';
						$box .= '<li><h4><span>'. __('Readers Rating', 'wprs') .'</span></h4></li>';
						$box .= '<li>'.$template['user_star_rating'].'</li>';
						$box .= '<li>'.$template['score_user'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">'.$template['price'].'</div>';
				
				$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
					$box .= '<ul class="al-right">';
						$box .= '<li><h4><span>'. __('Your Rating', 'wprs') .'</span></h4></li>';
						$box .= '<li>'.$template['user_rating_stars'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
			$box .= '</div>';
			
			$box .= '<hr />';
			
			$box .= '<div class="row">';
				$box .= '<div class="col-md-6 wprs_restaurant_details">';
					$box .= '<ul>';
						$box .= '<li><b>'.$template['item_name'].'</b></li>';
						$box .= '<li>'.$template['phone'].'</li>';
						$box .= '<li>'.$template['cuisine'].'</li>';
						$box .= '<li>'.$template['openhours'].'</li>';
						$box .= '<li>'.$template['restaurant_menu'].'</li>';
						$box .= '<li>'.$template['reservations'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				$box .= '<div class="col-md-6 wprs_restaurant_details">';
					$box .= '<ul>';
						$box .= '<li>'.$template['map'].'</li>';
						$box .= '<li>'.$template['address'].'</li>';
					$box .= '</ul>';
				$box .= '</div>';
			$box .= '</div>';
			
			/*
			$box .= '<div class="row">';
				$box .= '<div class="col-md-6">';
					$box .= '<ul>';
						//$box .= '<li>'.wprs_get_Thing($post->ID).'</li>';
						//$box .= '<li class="'.$template['reviewed_by_class'].'">'.wprs_get_author_name_person($post->ID, get_the_author()).'</li>';		
						//$box .= '<li class="'.$template['review_date_class'].'">'.wprs_get_dtreviewed().'</li>';
						//$box .= '<li class="'.$template['review_dmodified_class'].'">'.wprs_get_dtmodified().'</li>';
					$box .= '</ul>';
				$box .= '</div>';
				$box .= '<div class="col-md-6">'.wprs_get_criteria($post->ID, 'editor').'</div>';
			$box .= '</div>';
			*/
			$box .= '<hr />';

			$box .= '<div class="row">';
				$box .= '<div class="col-md-12">';
					$box .= $template['description'];
					$box .= $template['links'];
				$box .= '</div>';
			$box .= '</div>';
		
		$box .= '</div>';
			
	$box .= '</div>';
	$box .= '</div>';
	
	return apply_filters('wprs_template_restaurant_votes', $box);
	
}
