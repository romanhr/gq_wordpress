<?php
/*
	WP Rich Snippets - Restaurant aggregate review template
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function wprs_template_restaurant_aggregate() {
	
	global $post;
    	
	// define $box
	$box = '';
	
	// get box settings
	$template = wprs_template();
	
	
	// tabs
	$box .= '<div id="wprs_nav_tabs" class="wprs_container container-fluid">';
		$box .= '<div class="row">';$box .= '<div id="wprs_square">';
			//$box .= wprs_get_nav_tabs();
			$box .= $template['nav_tabs'];
		$box .= '</div>';
	$box .= '</div>';$box .= '</div>';

	// tab panes
	$box .= '<div id="wprs_nav_tabs_content" class="tab-content">';
			
	$box .= '<div class="tab-pane active" id="item_square">';
			
		$box .= '<div class="wprs_container container-fluid">';
			$box .= '<div class="row">';
		
				$box .= '<div id="wprs_square">';
			
					$box .= $template['media'];
			
					$box .= '<div class="row">';
						
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
							$box .= '<ul>';
								$box .= '<li><h4><span>'. __('User Rating', 'wprs') .'</span></h4></li>';
								$box .= '<li>'.$template['user_star_aggregate'].'</li>';
								$box .= '<li>'.$template['score_user'].'</li>';
							$box .= '</ul>';
						$box .= '</div>';
						
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">'.$template['price'].'</div>';
					
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
							$box .= '<ul class="al-right">';
								if ($template['percentage_user_average'] !='') {$box .= '<li>'.$template['percentage_user_average'].'</li>';}
								$box .= '<li>'.$template['userrating_review_count'].'</li>';
							$box .= '</ul">';
						$box .= '</div>';
					
					$box .= '</div>';
					
					$box .= '<hr />';
			
					$box .= '<div class="row">';
						$box .= '<div class="col-md-6 wprs_restaurant_details">';
							$box .= '<ul>';
								$box .= '<li><b>'.$template['item_name'].'</b></li>';
								$box .= '<li>'.$template['phone'].'</li>';
								$box .= '<li>'.$template['cuisine'].'</li>';
								$box .= '<li>'.$template['openhours'].'</li>';
								$box .= '<li>'.$template['restaurant_menu'].'</li>';
								$box .= '<li>'.$template['reservations'].'</li>';
							$box .= '</ul>';
						$box .= '</div>';
						$box .= '<div class="col-md-6 wprs_restaurant_details">';
							$box .= '<ul>';
								$box .= '<li>'.$template['map'].'</li>';
								$box .= '<li>'.$template['address'].'</li>';
							$box .= '</ul>';
						$box .= '</div>';
					$box .= '</div>';
			
					$box .= '<hr />';

					$box .= '<div class="row">';
						$box .= '<div class="summary col-md-12">';
							$box .= $template['description'];
							$box .= $template['links'];
						$box .= '</div>';
					$box .= '</div>';
	
				$box .= '</div>';
		
			$box .= '</div>';
		$box .= '</div>';


	$box .= '</div>';


	$box .= '<div class="tab-pane" id="user_reviews">';
		//$box .= wprs_get_user_reviews();
		$box .= $template['user_reviews'];
	$box .= '</div>';
		 
	$box .= '</div>';

	return apply_filters('wprs_template_restaurant_aggregate', $box);
	
}

