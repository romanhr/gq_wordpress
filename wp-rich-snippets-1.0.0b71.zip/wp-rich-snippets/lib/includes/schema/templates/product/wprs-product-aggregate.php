<?php
/*
	WP Rich Snippets - product aggregate review template
 
	WARNING: This file is part of the core WP Rich Snippets plugin. DO NOT edit
	this file under any circumstances.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function wprs_template_product_aggregate() {
	
	global $post;
    	
	// define $box
	$box = '';
	
	// get box settings
	$template = wprs_template();
	
	
	// tabs
	$box .= '<div id="wprs_nav_tabs" class="wprs_container container-fluid">';
		$box .= '<div class="row">';$box .= '<div id="wprs_square">';
			//$box .= wprs_get_nav_tabs();
			$box .= $template['nav_tabs'];
		$box .= '</div>';
	$box .= '</div>';$box .= '</div>';

	// tab panes
	$box .= '<div id="wprs_nav_tabs_content" class="tab-content">';
			
	$box .= '<div class="tab-pane active" id="item_square">';
			
		$box .= '<div class="wprs_container container-fluid">';
			$box .= '<div class="row">';
		
				$box .= '<div id="wprs_square">';
			
					$box .= $template['media'];
			
					$box .= '<div class="row">';
						
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
							$box .= '<ul>';
								$box .= '<li><h4><span>'. __('User Rating', 'wprs') .'</span></h4></li>';
								$box .= '<li>'.$template['user_star_aggregate'].'</li>';
								$box .= '<li>'.$template['score_user'].'</li>';
							$box .= '</ul>';
						$box .= '</div>';
						
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">'.$template['price'].'</div>';
					
						$box .= '<div class="col-xs-4 col-sm-4 col-md-4">';
							$box .= '<ul class="al-right">';
								if ($template['percentage_user_average'] !='') {$box .= '<li>'.$template['percentage_user_average'].'</li>';}
								$box .= '<li>'.$template['userrating_review_count'].'</li>';
							$box .= '</ul">';
						$box .= '</div>';
					
					$box .= '</div>';

					$box .= '<hr />';

					$box .= '<div class="row">';
						$box .= '<div class="summary col-md-12">';
							$box .= $template['description'];
							$box .= $template['links'];
						$box .= '</div>';
					$box .= '</div>';
	
				$box .= '</div>';
		
			$box .= '</div>';
		$box .= '</div>';


	$box .= '</div>';
	


	$box .= '<div class="tab-pane" id="user_reviews">';
		//$box .= wprs_get_user_reviews();
		$box .= $template['user_reviews'];
	$box .= '</div>';
		 
	$box .= '</div>';

	return apply_filters('wprs_template_product_aggregate', $box);
	
}

/* to do

<div itemprop="brand" itemscope itemtype="http://schema.org/Organization">
<span itemprop="name">[Brand]</span></div>
<div itemprop="manufacturer" itemscope itemtype="http://schema.org/Organization">
Manufactured by: <span itemprop="name">[Manufacturer]</span></div>
<div>Model: <span itemprop="model">[Model]</span></div>
*/

