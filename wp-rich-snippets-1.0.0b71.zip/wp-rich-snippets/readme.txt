Thanks for purchasing the WP Rich Snippets plugin!

This plugin adds Google�s Rich Snippets based on schema.org for a better WordPress SEO, it help you customize search results for more traffic and conversion.

See live demo in full action at http://wpleaders.com


=== How to install the plugin:

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to your Profile at http://authorhreview.com and generate your API key
4. Add your API key to the plugin settings page
5. Start rocking your site!


=== Google's Rich Snippets Testing Tool

After installing the plugin, and once you publish your first post on your blog, use Googl'e Structured Data Testing Tool to check your markup and make sure that Google can extract the structured data from your posts and pages.

The Structured Data Testing Tool will display a preview of how your review might appear in Google search results:

http://www.google.com/webmasters/tools/richsnippets


=== Need help?

Login to your account at http://authorhreview.com site and open a thread in the support forum.

Enjoy!