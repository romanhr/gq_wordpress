/* disable user rating on replies */
jQuery(document).on( 'click', 'a.comment-reply-link', function( event ) {
    jQuery('.user_rating_fileds').hide();
});

jQuery(document).on( 'click', 'a#cancel-comment-reply-link', function( event ) {
    jQuery('.user_rating_fileds').show();
});
