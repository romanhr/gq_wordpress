jQuery(document).ready(function($) {
	
	// image upload
	// wp 3.5+
	$('.wprs_media_upload').click(function(){
		var send_back = wp.media.editor.send.attachment,
			$this = $(this);
		wp.media.editor.send.attachment = function(props, attachment) {
			if (/image/i.test(attachment.mime)) {
				$this.parent().siblings('p.wprs_add_media').children('input').each(function() {
					var attr = $(this).attr('name');
					if (/wprs_post_image/.test(attr))
						$(this).val(attachment.sizes[props.size].url);
					else if (/height/.test(attr))
						$(this).val(attachment.sizes[props.size].height);
					else if (/width/.test(attr))
						$(this).val(attachment.sizes[props.size].width);
					else if (/id/.test(attr))
						$(this).val(attachment.id);
				});
				$this.parent().siblings('p.current_image').children('img').attr('src', attachment.sizes[props.size].url);
				$this.parent().siblings('p.current_image').show();
			}
			wp.media.editor.send.attachment = send_back;
		}
		wp.media.editor.open();
		return false;
	});
	
});
