<?php
/*
	Plugin Name: WP Rich Snippets
    Plugin URI: http://authorhreview.com
    Description: Add Google Rich Snippets support to your WordPress powered site.
    Version: 1.0.0b71
    Author: Hesham Zebida
    Author URI: http://zebida.com
    Last Version update : 27 August 2014
	Text Domain: wprs
	Domain Path: /lib/languages
	
	@author   AuthorhReview
	@license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
	@link     http://authorhreview.com/wp-rich-snippets/
	*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

add_action( 'wprs_init', 'wprs_constants' );
/**
 * This function defines the WP Rich Snippets constants
 *
 * @since 1.0.0
 */
function wprs_constants() {
	
	define( 'WPRICHSNIPPETS_PLUGINNAME', 'WP Rich Snippets' );
	// plugin version
	define( 'WPRICHSNIPPETS_VER', '1.0.0b71' );

	// define plugin URLs
	if ( ! defined( 'WPRICHSNIPPETS_URL' ) )
		define( 'WPRICHSNIPPETS_URL', plugin_dir_path( __FILE__ ) );
	define( 'WPRICHSNIPPETS_LIB_URL', trailingslashit( WPRICHSNIPPETS_URL . 'lib' ) );
	define( 'WPRICHSNIPPETS_ASSETS_URL', trailingslashit( WPRICHSNIPPETS_URL . 'assets' ) );
	//* admin
	define( 'WPRICHSNIPPETS_ADMIN_URL', trailingslashit( WPRICHSNIPPETS_LIB_URL . 'admin' ) );
	//* includes
	define( 'WPRICHSNIPPETS_INCLUDES_URL', trailingslashit( WPRICHSNIPPETS_LIB_URL . 'includes' ) );
	define( 'WPRICHSNIPPETS_MISC_URL', trailingslashit( WPRICHSNIPPETS_INCLUDES_URL . 'misc' ) );
	define( 'WPRICHSNIPPETS_TEMPLATES_URL', trailingslashit( WPRICHSNIPPETS_INCLUDES_URL . 'schema/templates' ) );
	//* assets
	define( 'WPRICHSNIPPETS_JS_URL', trailingslashit( WPRICHSNIPPETS_ASSETS_URL . 'js' ) );
	define( 'WPRICHSNIPPETS_CSS_URL', trailingslashit( WPRICHSNIPPETS_ASSETS_URL . 'css' ) );
	define( 'WPRICHSNIPPETS_IMG_URL', trailingslashit( WPRICHSNIPPETS_ASSETS_URL . 'images' ) );
	
	
	// define plugin URLs, for fast enqueuing scripts and styles
	if ( ! defined( 'WPRS_URL' ) )
		define( 'WPRS_URL', plugin_dir_url( __FILE__ ) );
	define( 'WPRS_INC_URL', trailingslashit( WPRS_URL . 'lib/includes' ) );
	define( 'WPRS_JS_URL', trailingslashit( WPRS_URL . 'assets/js' ) );
	define( 'WPRS_CSS_URL', trailingslashit( WPRS_URL . 'assets/css' ) );

}

// Localization
add_action('init', 'wprs_localization_init');
/**
 * Load the WP Rich Snippets textdomain for internationalization.
 *
 * @uses load_plugin_textdomain()
 *
 * @since 1.0.0
 */
function wprs_localization_init() {
	
	$path = dirname(plugin_basename( __FILE__ )) . '/lib/languages/';
	$loaded = load_plugin_textdomain('wprs', false, $path);
	if(isset($_GET['page'])) {
		if ($_GET['page'] == basename(__FILE__) && !$loaded) {          
			echo '<div class="error">WP Rich Snippets Localization: ' . __('Could not load the localization file: ' . $path, 'wprs') . '</div>';
			return;
		}
	}
	
}

//start the engine
include_once( 'lib/init.php' );
